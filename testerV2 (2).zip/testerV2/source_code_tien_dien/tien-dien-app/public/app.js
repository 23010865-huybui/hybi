'use strict';

const $ = (sel) => document.querySelector(sel);
const fmt = (n) => Number(n).toLocaleString('vi-VN');
const TYPE_LABEL = { HO_GIA_DINH: 'Hộ gia đình', THUE_NHA: 'Người thuê nhà' };
const STATUS_LABEL = { CHUA_THANH_TOAN: 'Chưa thanh toán', DA_THANH_TOAN: 'Đã thanh toán' };

const state = {
  token: sessionStorage.getItem('token'),
  user: JSON.parse(sessionStorage.getItem('user') || 'null'),
};

async function api(method, url, body) {
  const res = await fetch(url, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(state.token ? { Authorization: `Bearer ${state.token}` } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (res.status === 401 && state.token) {
    logout();
    throw new Error('Phiên đăng nhập đã hết hạn, vui lòng đăng nhập lại');
  }
  const data = res.status === 204 ? null : await res.json();
  if (!res.ok) throw new Error(data && data.error ? data.error : 'Có lỗi xảy ra');
  return data;
}

function setMsg(el, text, ok) {
  el.textContent = text;
  el.className = `msg ${ok ? 'success' : 'error'}`;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// ---------------- Điều hướng ----------------
function showPage(id) {
  ['page-login', 'page-register', 'page-app'].forEach((p) => $(`#${p}`).classList.toggle('hidden', p !== id));
}

function showView(id) {
  document.querySelectorAll('.view').forEach((v) => v.classList.toggle('hidden', v.id !== id));
  document.querySelectorAll('nav button').forEach((b) => b.classList.toggle('active', b.dataset.view === id));
  if (id === 'view-customers') loadCustomers();
  if (id === 'view-bills') { loadBillCustomers(); loadBills(); }
  if (id === 'view-tariff') loadTariff();
}

function enterApp() {
  showPage('page-app');
  $('#current-user').textContent = `${state.user.fullName} (${state.user.role === 'ADMIN' ? 'Quản trị' : 'Nhân viên'})`;
  document.querySelectorAll('.admin-only').forEach((el) => el.classList.toggle('hidden', state.user.role !== 'ADMIN'));
  showView('view-calc');
}

function logout() {
  state.token = null;
  state.user = null;
  sessionStorage.clear();
  showPage('page-login');
}

// Ẩn/hiện trường theo loại khách hàng
function bindTypeToggle(selectEl) {
  const scope = selectEl.closest('section');
  const apply = () => {
    const renter = selectEl.value === 'THUE_NHA';
    scope.querySelectorAll('.only-household').forEach((e) => e.classList.toggle('hidden', renter));
    scope.querySelectorAll('.only-renter').forEach((e) => e.classList.toggle('hidden', !renter));
  };
  selectEl.addEventListener('change', apply);
  apply();
}

// ---------------- Đăng nhập / Đăng ký ----------------
$('#login-btn').addEventListener('click', async () => {
  const err = $('#login-error');
  err.textContent = '';
  try {
    const data = await api('POST', '/api/auth/login', {
      username: $('#login-username').value.trim(),
      password: $('#login-password').value,
    });
    state.token = data.token;
    state.user = data.user;
    sessionStorage.setItem('token', data.token);
    sessionStorage.setItem('user', JSON.stringify(data.user));
    $('#login-password').value = '';
    enterApp();
  } catch (e) {
    setMsg(err, e.message, false);
  }
});
$('#login-password').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('#login-btn').click(); });

$('#reg-btn').addEventListener('click', async () => {
  try {
    await api('POST', '/api/auth/register', {
      username: $('#reg-username').value.trim(),
      fullName: $('#reg-fullname').value,
      password: $('#reg-password').value,
      confirmPassword: $('#reg-confirm').value,
    });
    setMsg($('#reg-message'), 'Đăng ký thành công. Vui lòng đăng nhập.', true);
  } catch (e) {
    setMsg($('#reg-message'), e.message, false);
  }
});

$('#goto-register').addEventListener('click', (e) => { e.preventDefault(); $('#reg-message').textContent = ''; showPage('page-register'); });
$('#goto-login').addEventListener('click', (e) => { e.preventDefault(); showPage('page-login'); });
$('#logout-btn').addEventListener('click', logout);
document.querySelectorAll('nav button').forEach((b) => b.addEventListener('click', () => showView(b.dataset.view)));

// ---------------- Tính nhanh ----------------
bindTypeToggle($('#calc-type'));
$('#calc-btn').addEventListener('click', async () => {
  $('#calc-error').textContent = '';
  $('#calc-result').classList.add('hidden');
  try {
    const r = await api('POST', '/api/calculate', {
      kwh: $('#calc-kwh').value.trim(),
      customerType: $('#calc-type').value,
      householdCount: $('#calc-households').value.trim(),
      personCount: $('#calc-persons').value.trim(),
    });
    $('#calc-breakdown tbody').innerHTML = r.breakdown.map((b) =>
      `<tr><td>${b.tier === 0 ? 'Đồng giá' : b.tier}</td><td>${fmt(b.kwh)}</td><td>${fmt(b.price)}</td><td>${fmt(b.amount)}</td></tr>`).join('');
    $('#calc-subtotal').textContent = `${fmt(r.subtotal)} đ`;
    $('#calc-vat').textContent = `${fmt(r.vat)} đ`;
    $('#calc-total').textContent = `${fmt(r.total)} đ`;
    $('#calc-result').classList.remove('hidden');
  } catch (e) {
    setMsg($('#calc-error'), e.message, false);
  }
});

// ---------------- Khách hàng ----------------
bindTypeToggle($('#cus-type'));

// ---- Kiểm tra dữ liệu ngay khi nhập (server vẫn kiểm tra lại toàn bộ) ----
const R = window.RulesVN;
const LIVE_RULES = {
  '#cus-code': (v) => R.checkCustomerCode(v),
  '#cus-name': (v) => R.checkPersonName(v, 'Tên khách hàng'),
  '#cus-address': (v) => R.checkAddress(v),
  '#cus-phone': (v) => {
    const r = R.analyzePhone(v);
    return { ok: r.ok, value: r.normalized, errors: r.ok ? [] : [r.message], okText: `✓ ${r.carrier}` };
  },
  '#reg-username': (v) => R.checkUsername(v),
  '#reg-fullname': (v) => R.checkPersonName(v, 'Họ tên'),
  '#reg-password': (v) => R.checkPassword(v, $('#reg-username').value.trim()),
};

function showHint(sel) {
  const input = $(sel);
  const hint = $(`${sel}-hint`);
  if (!hint) return;
  if (!input.value.trim()) { hint.textContent = ''; hint.className = 'hint'; return; }
  const r = LIVE_RULES[sel](input.value);
  hint.textContent = r.ok ? (r.okText || '✓ Hợp lệ') : r.errors[0];
  hint.className = `hint ${r.ok ? 'ok' : 'bad'}`;
}

Object.keys(LIVE_RULES).forEach((sel) => {
  $(sel).addEventListener('input', () => showHint(sel));
  // Khi rời ô: tự chuẩn hóa giá trị hợp lệ (viết hoa chữ đầu, bỏ khoảng trắng thừa, số điện thoại 0xxxxxxxxx)
  $(sel).addEventListener('blur', () => {
    if (sel === '#reg-password' || !$(sel).value.trim()) return;
    const r = LIVE_RULES[sel]($(sel).value);
    if (r.ok && r.value) $(sel).value = r.value;
    showHint(sel);
  });
});

// Chặn ký tự không hợp lệ ngay khi gõ
function restrictInput(sel, pattern) {
  $(sel).addEventListener('input', (e) => {
    const cleaned = e.target.value.replace(pattern, '');
    if (cleaned !== e.target.value) e.target.value = cleaned;
  });
}
restrictInput('#cus-phone', /[^0-9+ .\-()]/g);
restrictInput('#cus-households', /[^0-9]/g);
restrictInput('#cus-persons', /[^0-9]/g);
restrictInput('#cus-code', /[^a-zA-Z0-9]/g);

function clearHints() {
  document.querySelectorAll('.hint').forEach((h) => { h.textContent = ''; h.className = 'hint'; });
}

function resetCustomerForm() {
  $('#cus-id').value = '';
  ['#cus-code', '#cus-name', '#cus-phone', '#cus-address'].forEach((s) => { $(s).value = ''; });
  $('#cus-code').disabled = false;
  $('#cus-type').value = 'HO_GIA_DINH';
  $('#cus-type').dispatchEvent(new window.Event('change'));
  $('#cus-households').value = '1';
  $('#cus-persons').value = '0';
  clearHints();
  $('#cus-form-title').textContent = 'Thêm khách hàng';
}

async function loadCustomers() {
  const q = encodeURIComponent($('#cus-search').value.trim());
  try {
    const list = await api('GET', `/api/customers?q=${q}`);
    $('#cus-table tbody').innerHTML = list.length
      ? list.map((c) => `<tr data-code="${escapeHtml(c.code)}">
          <td>${escapeHtml(c.code)}</td><td>${escapeHtml(c.name)}</td><td>${escapeHtml(c.phone)}</td>
          <td>${escapeHtml(c.address)}</td><td>${TYPE_LABEL[c.type]}</td>
          <td>${c.type === 'HO_GIA_DINH' ? `${c.householdCount} hộ` : `${c.personCount} người`}</td>
          <td><button class="btn-edit" data-id="${c.id}">Sửa</button>
              <button class="btn-delete danger" data-id="${c.id}">Xóa</button></td></tr>`).join('')
      : '<tr class="empty"><td colspan="7">Không có khách hàng phù hợp</td></tr>';
    list.forEach((c) => { state[`cus_${c.id}`] = c; });
  } catch (e) {
    setMsg($('#cus-message'), e.message, false);
  }
}

$('#cus-search-btn').addEventListener('click', loadCustomers);
$('#cus-cancel-btn').addEventListener('click', () => { resetCustomerForm(); $('#cus-message').textContent = ''; });

$('#cus-save-btn').addEventListener('click', async () => {
  const id = $('#cus-id').value;
  const body = {
    code: $('#cus-code').value,
    name: $('#cus-name').value,
    phone: $('#cus-phone').value,
    address: $('#cus-address').value,
    type: $('#cus-type').value,
    householdCount: $('#cus-households').value,
    personCount: $('#cus-persons').value,
  };
  try {
    if (id) await api('PUT', `/api/customers/${id}`, body);
    else await api('POST', '/api/customers', body);
    setMsg($('#cus-message'), id ? 'Cập nhật khách hàng thành công' : 'Thêm khách hàng thành công', true);
    resetCustomerForm();
    loadCustomers();
  } catch (e) {
    setMsg($('#cus-message'), e.message, false);
  }
});

$('#cus-table').addEventListener('click', async (e) => {
  const id = e.target.dataset.id;
  if (!id) return;
  if (e.target.classList.contains('btn-edit')) {
    const c = state[`cus_${id}`];
    $('#cus-id').value = c.id;
    $('#cus-code').value = c.code;
    $('#cus-code').disabled = true;
    $('#cus-name').value = c.name;
    $('#cus-phone').value = c.phone;
    $('#cus-address').value = c.address;
    $('#cus-type').value = c.type;
    $('#cus-type').dispatchEvent(new window.Event('change'));
    $('#cus-households').value = c.householdCount;
    $('#cus-persons').value = c.personCount;
    $('#cus-form-title').textContent = `Sửa khách hàng ${c.code}`;
    $('#cus-message').textContent = '';
  } else if (e.target.classList.contains('btn-delete')) {
    if (!confirm('Bạn có chắc muốn xóa khách hàng này?')) return;
    try {
      await api('DELETE', `/api/customers/${id}`);
      setMsg($('#cus-message'), 'Xóa khách hàng thành công', true);
      loadCustomers();
    } catch (err) {
      setMsg($('#cus-message'), err.message, false);
    }
  }
});

// ---------------- Ghi chỉ số & Hóa đơn ----------------
async function loadBillCustomers() {
  const list = await api('GET', '/api/customers');
  $('#bill-customer').innerHTML = '<option value="">-- Chọn khách hàng --</option>' +
    list.map((c) => `<option value="${c.id}">${escapeHtml(c.code)} - ${escapeHtml(c.name)}</option>`).join('');
  $('#bill-old').value = '0';
  $('#bill-old').readOnly = false;
}

$('#bill-customer').addEventListener('change', async () => {
  const id = $('#bill-customer').value;
  if (!id) return;
  const last = await api('GET', `/api/customers/${id}/last-reading`);
  // Đã có kỳ trước: chỉ số cũ = chỉ số mới của kỳ trước, không cho sửa
  $('#bill-old').value = last ? last.newIndex : '0';
  $('#bill-old').readOnly = Boolean(last);
});

async function loadBills() {
  const month = encodeURIComponent($('#bill-filter-month').value.trim());
  const list = await api('GET', `/api/bills${month ? `?month=${month}` : ''}`);
  $('#bill-table tbody').innerHTML = list.length
    ? list.map((b) => `<tr data-id="${b.id}">
        <td>${b.month}</td><td>${escapeHtml(b.customerCode)}</td><td>${escapeHtml(b.customerName)}</td>
        <td>${fmt(b.oldIndex)}</td><td>${fmt(b.newIndex)}</td><td>${fmt(b.kwh)}</td><td>${fmt(b.total)}</td>
        <td class="status">${STATUS_LABEL[b.status]}</td>
        <td>${b.status === 'CHUA_THANH_TOAN' ? `<button class="btn-pay" data-id="${b.id}">Thanh toán</button>` : ''}</td></tr>`).join('')
    : '<tr class="empty"><td colspan="9">Chưa có hóa đơn</td></tr>';
}

$('#bill-filter-btn').addEventListener('click', loadBills);

$('#bill-save-btn').addEventListener('click', async () => {
  try {
    const bill = await api('POST', '/api/bills', {
      customerId: $('#bill-customer').value,
      month: $('#bill-month').value,
      oldIndex: $('#bill-old').value,
      newIndex: $('#bill-new').value,
    });
    setMsg($('#bill-message'), `Lập hóa đơn thành công: ${fmt(bill.kwh)} kWh, tổng tiền ${fmt(bill.total)} đ`, true);
    $('#bill-new').value = '';
    $('#bill-customer').dispatchEvent(new window.Event('change'));
    loadBills();
  } catch (e) {
    setMsg($('#bill-message'), e.message, false);
  }
});

$('#bill-table').addEventListener('click', async (e) => {
  if (!e.target.classList.contains('btn-pay')) return;
  try {
    await api('PATCH', `/api/bills/${e.target.dataset.id}/pay`);
    loadBills();
  } catch (err) {
    setMsg($('#bill-message'), err.message, false);
  }
});

// ---------------- Biểu giá ----------------
async function loadTariff() {
  const t = await api('GET', '/api/tariff');
  const isAdmin = state.user.role === 'ADMIN';
  $('#tariff-name').textContent = t.name;
  $('#tariff-table tbody').innerHTML = t.tiers.map((tier, i) => {
    const last = i === t.tiers.length - 1;
    return `<tr><td>${i + 1}</td>
      <td>${last ? 'Phần còn lại' : `<input class="tier-width" type="text" value="${tier.width}" ${isAdmin ? '' : 'disabled'}>`}</td>
      <td><input class="tier-price" type="text" value="${tier.price}" ${isAdmin ? '' : 'disabled'}></td></tr>`;
  }).join('');
  $('#tariff-undeclared').value = t.undeclaredPrice;
  $('#tariff-vat').value = Math.round(t.vatRate * 10000) / 100;
  $('#tariff-undeclared').disabled = !isAdmin;
  $('#tariff-vat').disabled = !isAdmin;
  $('#tariff-message').textContent = '';
}

$('#tariff-save-btn').addEventListener('click', async () => {
  const rows = [...document.querySelectorAll('#tariff-table tbody tr')];
  const tiers = rows.map((r, i) => ({
    width: i === rows.length - 1 ? null : r.querySelector('.tier-width').value.trim(),
    price: r.querySelector('.tier-price').value.trim(),
  }));
  const vatText = $('#tariff-vat').value.trim();
  const vat = /^\d+(\.\d+)?$/.test(vatText) ? Number(vatText) / 100 : NaN;
  try {
    await api('PUT', '/api/tariff', { tiers, undeclaredPrice: $('#tariff-undeclared').value.trim(), vatRate: vat });
    setMsg($('#tariff-message'), 'Cập nhật biểu giá thành công', true);
  } catch (e) {
    setMsg($('#tariff-message'), e.message, false);
  }
});

// ---------------- Khởi động ----------------
if (state.token && state.user) enterApp();
else showPage('page-login');
