/**
 * Bộ quy tắc kiểm tra dữ liệu dùng chung cho trình duyệt (window.RulesVN) và server (require).
 * Tham khảo cách kiểm tra của các sàn TMĐT (Shopee, Tiki, Lazada) và quy định hành chính hiện hành:
 *  - Số di động 10 số theo đầu số các nhà mạng (sau chuyển đổi 11 → 10 số năm 2018).
 *  - Địa chỉ 2 cấp (Xã/Phường – Tỉnh/Thành phố) theo Nghị quyết 202/2025/QH15, hiệu lực 01/07/2025: 34 tỉnh, thành.
 * Mỗi hàm check* trả về { ok, value (đã chuẩn hóa), errors[] }.
 */
(function (root) {
  'use strict';

  // ======================= SỐ ĐIỆN THOẠI =======================
  const CARRIERS = {
    Viettel: ['032', '033', '034', '035', '036', '037', '038', '039', '086', '096', '097', '098'],
    Vinaphone: ['081', '082', '083', '084', '085', '088', '091', '094'],
    MobiFone: ['070', '076', '077', '078', '079', '089', '090', '093'],
    Vietnamobile: ['052', '056', '058', '092'],
    Gmobile: ['059', '099'],
    iTel: ['087'],
    Wintel: ['055'],
  };
  const PREFIX_TO_CARRIER = {};
  Object.keys(CARRIERS).forEach((name) => CARRIERS[name].forEach((p) => { PREFIX_TO_CARRIER[p] = name; }));

  function fail(code, message) {
    return { ok: false, code, message, normalized: null, carrier: null };
  }

  /** Phân tích số di động; chấp nhận dấu cách, chấm, gạch ngang, ngoặc, tiền tố +84/84; chuẩn hóa về 0xxxxxxxxx. */
  function analyzePhone(raw) {
    if (raw === undefined || raw === null || String(raw).trim() === '') {
      return fail('EMPTY', 'Số điện thoại không được để trống');
    }
    const s = String(raw).trim();
    if (!/^\+?[0-9 .\-()]+$/.test(s)) {
      return fail('INVALID_CHAR', 'Số điện thoại chỉ được chứa chữ số (cho phép dấu cách, dấu chấm, gạch ngang hoặc +84 ở đầu)');
    }
    if (/[ .-]{2,}/.test(s) || (s.match(/\(/g) || []).length !== (s.match(/\)/g) || []).length) {
      return fail('BAD_FORMAT', 'Số điện thoại sai định dạng (không dùng liên tiếp nhiều dấu phân cách, dấu ngoặc phải đủ cặp)');
    }
    let digits = s.replace(/[ .\-()]/g, '');
    if (digits.startsWith('+')) {
      if (!digits.startsWith('+84')) return fail('FOREIGN', 'Chỉ chấp nhận số điện thoại Việt Nam (mã quốc gia +84)');
      digits = '0' + digits.slice(3);
    } else if (digits.startsWith('84') && digits.length === 11) {
      digits = '0' + digits.slice(2);
    }
    if (digits.startsWith('00')) return fail('DOUBLE_ZERO', 'Số điện thoại không được bắt đầu bằng 00');
    if (!digits.startsWith('0')) return fail('NO_LEADING_ZERO', 'Số điện thoại phải bắt đầu bằng số 0 hoặc +84');
    if (digits.startsWith('02')) {
      return fail('LANDLINE', 'Chỉ chấp nhận số điện thoại di động, không chấp nhận số máy bàn (đầu 02x)');
    }
    if (digits.startsWith('01') && digits.length === 11) {
      return fail('OLD_11_DIGIT', 'Thuê bao 11 số đầu 01x đã chuyển sang 10 số từ năm 2018, vui lòng nhập số mới');
    }
    if (digits.length !== 10) {
      return fail('LENGTH', `Số điện thoại di động phải gồm đúng 10 chữ số (đang có ${digits.length})`);
    }
    const prefix = digits.slice(0, 3);
    const carrier = PREFIX_TO_CARRIER[prefix];
    if (!carrier) return fail('UNKNOWN_PREFIX', `Đầu số ${prefix} không thuộc nhà mạng di động nào tại Việt Nam`);
    const tail = digits.slice(3);
    if (/^(\d)\1{6}$/.test(tail)) {
      return fail('FAKE_REPEAT', 'Số điện thoại không hợp lệ (7 số cuối giống nhau)');
    }
    if ('0123456789'.includes(tail) || '9876543210'.includes(tail)) {
      return fail('FAKE_SEQUENCE', 'Số điện thoại không hợp lệ (7 số cuối là dãy số liên tiếp)');
    }
    return { ok: true, code: 'OK', message: '', normalized: digits, carrier };
  }

  // ======================= CHUẨN HÓA CHUỖI =======================
  function clean(v) {
    if (v === undefined || v === null) return '';
    return String(v).normalize('NFC').replace(/\s+/g, ' ').trim();
  }

  function titleCase(s) {
    return s.split(' ').map((w) => w.charAt(0).toLocaleUpperCase('vi') + w.slice(1).toLocaleLowerCase('vi')).join(' ');
  }

  // Bỏ dấu tiếng Việt để so khớp tên tỉnh
  function fold(s) {
    return s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D')
      .toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
  }

  // ======================= HỌ TÊN =======================
  const LETTER_WORDS = /^[\p{L}\p{M}]+( [\p{L}\p{M}]+)*$/u;

  /** Kiểm tra họ tên người (dùng cho tên khách hàng và họ tên tài khoản). */
  function checkPersonName(raw, label) {
    const errors = [];
    const v = clean(raw);
    if (!v) return { ok: false, value: v, errors: [`${label} không được để trống`] };
    if (v.length < 2 || v.length > 100) errors.push(`${label} từ 2 đến 100 ký tự`);
    if (!LETTER_WORDS.test(v)) {
      errors.push(`${label} chỉ được chứa chữ cái và dấu cách (không chứa số, ký tự đặc biệt)`);
    } else {
      const words = v.split(' ');
      if (words.length < 2) errors.push(`${label} phải gồm ít nhất họ và tên (2 từ trở lên)`);
      if (words.length > 10) errors.push(`${label} tối đa 10 từ`);
      if (words.some((w) => w.length > 15)) errors.push(`${label} có từ quá dài (tối đa 15 chữ cái mỗi từ)`);
      if (/(\p{L})\1\1/iu.test(v)) errors.push(`${label} không được có 3 chữ cái giống nhau liên tiếp`);
    }
    return { ok: errors.length === 0, value: errors.length ? v : titleCase(v), errors };
  }

  // ======================= ĐỊA CHỈ =======================
  const PROVINCES = [
    'Hà Nội', 'Huế', 'Hải Phòng', 'Đà Nẵng', 'Hồ Chí Minh', 'Cần Thơ',
    'Tuyên Quang', 'Cao Bằng', 'Lai Châu', 'Lào Cai', 'Thái Nguyên', 'Điện Biên', 'Lạng Sơn', 'Sơn La',
    'Phú Thọ', 'Bắc Ninh', 'Quảng Ninh', 'Hưng Yên', 'Ninh Bình', 'Thanh Hóa', 'Nghệ An', 'Hà Tĩnh',
    'Quảng Trị', 'Quảng Ngãi', 'Gia Lai', 'Khánh Hòa', 'Lâm Đồng', 'Đắk Lắk', 'Đồng Nai', 'Tây Ninh',
    'Vĩnh Long', 'Đồng Tháp', 'Cà Mau', 'An Giang',
  ];
  const PROVINCE_KEYS = {};
  PROVINCES.forEach((p) => { PROVINCE_KEYS[fold(p)] = p; });
  Object.assign(PROVINCE_KEYS, {
    'hcm': 'Hồ Chí Minh', 'tphcm': 'Hồ Chí Minh', 'sai gon': 'Hồ Chí Minh', 'hn': 'Hà Nội',
    'thanh hoa': 'Thanh Hóa', 'thua thien hue': 'Huế', 'khanh hoa': 'Khánh Hòa', 'dak lak': 'Đắk Lắk',
  });
  const PROVINCE_PREFIX = /^(tinh|thanh pho|tp)\s+/;

  /** Trả về tên chuẩn của tỉnh/thành phố hoặc null. */
  function matchProvince(part) {
    let k = fold(part).replace(/^tp(?=[a-z])/, 'tp ');
    k = k.replace(PROVINCE_PREFIX, '');
    if (k === 'tp hcm' || k === 'tp ho chi minh') k = 'hcm';
    return PROVINCE_KEYS[k] || PROVINCE_KEYS[k.replace(/ /g, '')] || null;
  }

  const ADDRESS_CHARS = /^[\p{L}\p{M}0-9 ,./\-#()]+$/u;
  const RURAL_START = /^(thôn|xóm|ấp|bản|làng|khu|tổ|buôn|sóc|đội|khóm|ktx|tòa|chung cư)\b/iu;

  function checkAddress(raw) {
    const errors = [];
    const v = clean(raw).replace(/\s*,\s*/g, ', ');
    if (!v) return { ok: false, value: v, errors: ['Địa chỉ không được để trống'] };
    if (v.length < 10 || v.length > 200) errors.push('Địa chỉ từ 10 đến 200 ký tự');
    if (!ADDRESS_CHARS.test(v)) {
      const bad = [...new Set(v.replace(/[\p{L}\p{M}0-9 ,./\-#()]/gu, ''))].join(' ');
      errors.push(`Địa chỉ chứa ký tự không hợp lệ: ${bad} (chỉ cho phép chữ, số, dấu cách và , . / - # ( ))`);
    }
    if (/[,./\-#]{2,}/.test(v.replace(/, /g, ','))) errors.push('Địa chỉ không được có các dấu câu liên tiếp');
    if (!/\p{L}/u.test(v)) errors.push('Địa chỉ phải chứa chữ cái');
    const parts = v.split(', ').map((p) => p.trim());
    if (parts.length < 3) {
      errors.push('Địa chỉ phải gồm ít nhất 3 phần, cách nhau bởi dấu phẩy: Số nhà/Thôn, đường – Xã/Phường – Tỉnh/Thành phố');
    } else {
      if (parts.some((p) => p.length < 2 || !/\p{L}|\d/u.test(p))) errors.push('Mỗi phần của địa chỉ phải có ít nhất 2 ký tự');
      if (!/\d/.test(parts[0]) && !RURAL_START.test(parts[0])) {
        errors.push('Phần đầu địa chỉ phải có số nhà hoặc bắt đầu bằng Thôn/Xóm/Ấp/Bản/Tổ/Khu…');
      }
      const prov = matchProvince(parts[parts.length - 1]);
      if (!prov) {
        errors.push(`“${parts[parts.length - 1]}” không phải tỉnh/thành phố hợp lệ (theo danh sách 34 tỉnh, thành từ 01/07/2025)`);
      } else {
        // Chuẩn hóa tên tỉnh/thành phố như cách các sàn TMĐT hiển thị
        parts[parts.length - 1] = prov === 'Hồ Chí Minh' ? 'TP. Hồ Chí Minh' : prov;
      }
    }
    if (errors.length) return { ok: false, value: v, errors };
    const value = parts.map((p) => p.charAt(0).toLocaleUpperCase('vi') + p.slice(1)).join(', ');
    return { ok: true, value, errors };
  }

  // ======================= MÃ KHÁCH HÀNG =======================
  function checkCustomerCode(raw) {
    const v = clean(raw).toUpperCase();
    if (!v) return { ok: false, value: v, errors: ['Mã khách hàng không được để trống'] };
    if (!/^KH\d{6}$/.test(v)) return { ok: false, value: v, errors: ['Mã khách hàng có dạng KH + 6 chữ số (VD: KH000001)'] };
    if (v === 'KH000000') return { ok: false, value: v, errors: ['Mã khách hàng phải từ KH000001 trở lên'] };
    return { ok: true, value: v, errors: [] };
  }

  // ======================= TÀI KHOẢN =======================
  const RESERVED = ['admin', 'administrator', 'root', 'system', 'sysadmin', 'support', 'test', 'null', 'undefined'];

  function checkUsername(raw) {
    const v = raw === undefined || raw === null ? '' : String(raw).trim();
    const errors = [];
    if (!v) return { ok: false, value: v, errors: ['Tên đăng nhập không được để trống'] };
    if (!/^[a-zA-Z0-9_]{4,30}$/.test(v)) errors.push('Tên đăng nhập gồm 4-30 ký tự chữ, số hoặc dấu gạch dưới');
    else {
      if (!/^[a-zA-Z]/.test(v)) errors.push('Tên đăng nhập phải bắt đầu bằng chữ cái');
      if (/__/.test(v) || /_$/.test(v)) errors.push('Tên đăng nhập không được có 2 dấu gạch dưới liên tiếp hoặc kết thúc bằng dấu gạch dưới');
      if (RESERVED.includes(v.toLowerCase())) errors.push('Tên đăng nhập này đã được hệ thống dành riêng');
    }
    return { ok: errors.length === 0, value: v, errors };
  }

  function checkPassword(pw, username) {
    const errors = [];
    if (pw === undefined || pw === null || pw === '') return { ok: false, errors: ['Mật khẩu không được để trống'] };
    if (pw.length < 8 || pw.length > 50) errors.push('Mật khẩu phải từ 8 đến 50 ký tự');
    if (!/[a-z]/.test(pw) || !/[A-Z]/.test(pw) || !/\d/.test(pw)) {
      errors.push('Mật khẩu phải có ít nhất 1 chữ thường, 1 chữ hoa và 1 chữ số');
    }
    if (/\s/.test(pw)) errors.push('Mật khẩu không được chứa dấu cách');
    if (username && String(username).length >= 4 && pw.toLowerCase().includes(String(username).toLowerCase())) {
      errors.push('Mật khẩu không được chứa tên đăng nhập');
    }
    return { ok: errors.length === 0, errors };
  }

  const api = {
    analyzePhone, checkPersonName, checkAddress, checkCustomerCode, checkUsername, checkPassword,
    matchProvince, PROVINCES, CARRIERS, PREFIX_TO_CARRIER,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.RulesVN = api;
}(typeof window !== 'undefined' ? window : this));
