'use strict';
const request = require('supertest');
const { openDb } = require('../../src/db');
const { createApp } = require('../../src/app');

let app;
let adminToken;
let staffToken;

async function login(username, password) {
  const res = await request(app).post('/api/auth/login').send({ username, password });
  return res.body.token;
}

const customer = (patch = {}) => ({
  code: 'KH000001', name: 'Nguyễn Văn A', phone: '0912468357', address: 'Số 1 Nguyễn Trác, Yên Nghĩa, Hà Nội',
  type: 'HO_GIA_DINH', householdCount: '1', ...patch,
});

beforeEach(async () => {
  app = createApp(openDb(':memory:'));
  adminToken = await login('admin', 'Admin@123');
  staffToken = await login('nhanvien', 'Nhanvien123');
});

describe('IT-AUTH: Đăng ký / đăng nhập', () => {
  test('IT-AUTH-01: đăng nhập đúng trả về token', async () => {
    const res = await request(app).post('/api/auth/login').send({ username: 'admin', password: 'Admin@123' });
    expect(res.status).toBe(200);
    expect(res.body.token).toBeTruthy();
    expect(res.body.user.role).toBe('ADMIN');
  });
  test('IT-AUTH-02: sai mật khẩu -> 401', async () => {
    const res = await request(app).post('/api/auth/login').send({ username: 'admin', password: 'sai' });
    expect(res.status).toBe(401);
    expect(res.body.error).toBe('Tên đăng nhập hoặc mật khẩu không đúng');
  });
  test('IT-AUTH-03: tài khoản không tồn tại -> 401 cùng thông báo', async () => {
    const res = await request(app).post('/api/auth/login').send({ username: 'khongco', password: 'abc123' });
    expect(res.status).toBe(401);
    expect(res.body.error).toBe('Tên đăng nhập hoặc mật khẩu không đúng');
  });
  test('IT-AUTH-04: bỏ trống -> 400', async () => {
    const res = await request(app).post('/api/auth/login').send({});
    expect(res.status).toBe(400);
  });
  test('IT-AUTH-05: đăng ký thành công rồi đăng nhập được', async () => {
    const reg = await request(app).post('/api/auth/register')
      .send({ username: 'tester01', fullName: 'Nguyễn Tester', password: 'Matkhau123', confirmPassword: 'Matkhau123' });
    expect(reg.status).toBe(201);
    expect(reg.body.role).toBe('STAFF');
    expect(await login('tester01', 'Matkhau123')).toBeTruthy();
  });
  test('IT-AUTH-06: đăng ký trùng tên (không phân biệt hoa thường) -> 409', async () => {
    const res = await request(app).post('/api/auth/register')
      .send({ username: 'NhanVien', fullName: 'Nguyễn Văn X', password: 'Matkhau123', confirmPassword: 'Matkhau123' });
    expect(res.status).toBe(409);
  });
  test('IT-AUTH-08: đăng ký tên dành riêng (admin) -> 400', async () => {
    const res = await request(app).post('/api/auth/register')
      .send({ username: 'Admin', fullName: 'Nguyễn Văn X', password: 'Matkhau123', confirmPassword: 'Matkhau123' });
    expect(res.status).toBe(400);
  });
  test('IT-AUTH-07: mật khẩu không được lưu dạng rõ', async () => {
    const db = openDb(':memory:');
    const row = db.prepare("SELECT password_hash FROM users WHERE username='admin'").get();
    expect(row.password_hash).not.toBe('Admin@123');
    expect(row.password_hash.startsWith('$2')).toBe(true);
  });
});

describe('IT-SEC: Bảo mật truy cập', () => {
  test('IT-SEC-01: gọi API không có token -> 401', async () => {
    const res = await request(app).get('/api/customers');
    expect(res.status).toBe(401);
  });
  test('IT-SEC-02: token giả mạo -> 401', async () => {
    const res = await request(app).get('/api/customers').set('Authorization', 'Bearer abc.def.ghi');
    expect(res.status).toBe(401);
  });
  test('IT-SEC-03: nhân viên sửa biểu giá -> 403', async () => {
    const res = await request(app).put('/api/tariff').set('Authorization', `Bearer ${staffToken}`)
      .send({ tiers: [{ price: 1 }], undeclaredPrice: 1, vatRate: 0 });
    expect(res.status).toBe(403);
  });
  test('IT-SEC-04: SQL injection trong ô tìm kiếm không làm lộ dữ liệu', async () => {
    await request(app).post('/api/customers').set('Authorization', `Bearer ${adminToken}`).send(customer());
    const res = await request(app).get("/api/customers?q=' OR '1'='1").set('Authorization', `Bearer ${adminToken}`);
    expect(res.status).toBe(200);
    expect(res.body).toEqual([]);
  });
  test('IT-SEC-06: SQL injection ở ô đăng nhập bị từ chối', async () => {
    const res = await request(app).post('/api/auth/login').send({ username: "admin' OR '1'='1", password: "' OR '1'='1" });
    expect(res.status).toBe(401);
    expect(res.body.token).toBeUndefined();
  });
  test('IT-SEC-05: JSON sai định dạng -> 400', async () => {
    const res = await request(app).post('/api/auth/login').set('Content-Type', 'application/json').send('{abc');
    expect(res.status).toBe(400);
  });
});

describe('IT-CUS: Quản lý khách hàng', () => {
  const auth = () => ({ Authorization: `Bearer ${adminToken}` });
  test('IT-CUS-01: thêm, tìm kiếm, sửa, xóa', async () => {
    const add = await request(app).post('/api/customers').set(auth()).send(customer());
    expect(add.status).toBe(201);
    const found = await request(app).get('/api/customers?q=Văn A').set(auth());
    expect(found.body).toHaveLength(1);
    const upd = await request(app).put(`/api/customers/${add.body.id}`).set(auth())
      .send(customer({ name: 'Nguyễn Văn B', type: 'THUE_NHA', personCount: '6' }));
    expect(upd.status).toBe(200);
    expect(upd.body).toMatchObject({ name: 'Nguyễn Văn B', type: 'THUE_NHA', personCount: 6, code: 'KH000001' });
    const del = await request(app).delete(`/api/customers/${add.body.id}`).set(auth());
    expect(del.status).toBe(204);
  });
  test('IT-CUS-02: mã khách hàng trùng -> 409', async () => {
    await request(app).post('/api/customers').set(auth()).send(customer());
    const res = await request(app).post('/api/customers').set(auth()).send(customer({ name: 'Trần Văn Khác' }));
    expect(res.status).toBe(409);
  });
  test('IT-CUS-03: dữ liệu không hợp lệ -> 400 kèm danh sách lỗi', async () => {
    const res = await request(app).post('/api/customers').set(auth()).send(customer({ phone: '123', householdCount: 'abc' }));
    expect(res.status).toBe(400);
    expect(res.body.errors.length).toBe(2);
  });
  test('IT-CUS-04: mã khách hàng chữ thường được chuẩn hóa thành chữ hoa', async () => {
    const res = await request(app).post('/api/customers').set(auth()).send(customer({ code: 'kh000009' }));
    expect(res.status).toBe(201);
    expect(res.body.code).toBe('KH000009');
  });
  test('IT-CUS-05: không xóa được khách hàng đã có hóa đơn', async () => {
    const add = await request(app).post('/api/customers').set(auth()).send(customer());
    await request(app).post('/api/bills').set(auth()).send({ customerId: add.body.id, month: '2026-08', oldIndex: 0, newIndex: 100 });
    const res = await request(app).delete(`/api/customers/${add.body.id}`).set(auth());
    expect(res.status).toBe(409);
  });
  test('IT-CUS-07: số điện thoại trùng với khách hàng khác -> 409 (thêm và sửa)', async () => {
    await request(app).post('/api/customers').set(auth()).send(customer());
    const b = await request(app).post('/api/customers').set(auth()).send(customer({ code: 'KH000002', phone: '0386452917' }));
    const dup = await request(app).post('/api/customers').set(auth()).send(customer({ code: 'KH000003', phone: '+84 912 468 357' }));
    expect(dup.status).toBe(409);
    expect(dup.body.error).toContain('KH000001');
    const upd = await request(app).put(`/api/customers/${b.body.id}`).set(auth()).send(customer({ phone: '0912468357' }));
    expect(upd.status).toBe(409);
  });
  test('IT-CUS-08: dữ liệu được chuẩn hóa trước khi lưu', async () => {
    const res = await request(app).post('/api/customers').set(auth())
      .send(customer({ name: '  trần   thị bình ', phone: '0912 468 357', address: 'số 5 lê lợi,phường bến thành,tp hcm' }));
    expect(res.status).toBe(201);
    expect(res.body).toMatchObject({ name: 'Trần Thị Bình', phone: '0912468357', address: 'Số 5 lê lợi, Phường bến thành, TP. Hồ Chí Minh' });
  });
  test('IT-CUS-09: số điện thoại đầu 00 -> 400', async () => {
    const res = await request(app).post('/api/customers').set(auth()).send(customer({ phone: '0012468357' }));
    expect(res.status).toBe(400);
    expect(res.body.error).toContain('không được bắt đầu bằng 00');
  });
  test('IT-CUS-06: sửa/xóa khách hàng không tồn tại -> 404', async () => {
    expect((await request(app).put('/api/customers/999').set(auth()).send(customer())).status).toBe(404);
    expect((await request(app).delete('/api/customers/999').set(auth())).status).toBe(404);
  });
});

describe('IT-BILL: Ghi chỉ số và lập hóa đơn', () => {
  const auth = () => ({ Authorization: `Bearer ${staffToken}` });
  let cid;
  beforeEach(async () => {
    cid = (await request(app).post('/api/customers').set(auth()).send(customer())).body.id;
  });
  test('IT-BILL-01: lập hóa đơn kỳ đầu, 150 kWh', async () => {
    const res = await request(app).post('/api/bills').set(auth()).send({ customerId: cid, month: '2026-08', oldIndex: '1000', newIndex: '1150' });
    expect(res.status).toBe(201);
    expect(res.body).toMatchObject({ kwh: 150, subtotal: 320700, vat: 25656, total: 346356, status: 'CHUA_THANH_TOAN' });
  });
  test('IT-BILL-02: kỳ sau tự lấy chỉ số cũ từ kỳ trước (bỏ qua giá trị gửi lên)', async () => {
    await request(app).post('/api/bills').set(auth()).send({ customerId: cid, month: '2026-08', oldIndex: 0, newIndex: 100 });
    const res = await request(app).post('/api/bills').set(auth()).send({ customerId: cid, month: '2026-09', oldIndex: 0, newIndex: 150 });
    expect(res.status).toBe(201);
    expect(res.body.oldIndex).toBe(100);
    expect(res.body.kwh).toBe(50);
  });
  test('IT-BILL-03: trùng kỳ -> 409', async () => {
    await request(app).post('/api/bills').set(auth()).send({ customerId: cid, month: '2026-08', oldIndex: 0, newIndex: 100 });
    const res = await request(app).post('/api/bills').set(auth()).send({ customerId: cid, month: '2026-08', newIndex: 200 });
    expect(res.status).toBe(409);
  });
  test('IT-BILL-04: kỳ trước kỳ gần nhất -> 400', async () => {
    await request(app).post('/api/bills').set(auth()).send({ customerId: cid, month: '2026-08', oldIndex: 0, newIndex: 100 });
    const res = await request(app).post('/api/bills').set(auth()).send({ customerId: cid, month: '2026-07', newIndex: 200 });
    expect(res.status).toBe(400);
  });
  test('IT-BILL-05: chỉ số mới nhỏ hơn chỉ số cũ -> 400', async () => {
    const res = await request(app).post('/api/bills').set(auth()).send({ customerId: cid, month: '2026-08', oldIndex: 500, newIndex: 499 });
    expect(res.status).toBe(400);
    expect(res.body.error).toContain('Chỉ số mới không được nhỏ hơn chỉ số cũ');
  });
  test('IT-BILL-06: thanh toán hóa đơn, thanh toán lần 2 -> 409', async () => {
    const bill = (await request(app).post('/api/bills').set(auth()).send({ customerId: cid, month: '2026-08', oldIndex: 0, newIndex: 100 })).body;
    expect((await request(app).patch(`/api/bills/${bill.id}/pay`).set(auth())).status).toBe(200);
    expect((await request(app).patch(`/api/bills/${bill.id}/pay`).set(auth())).status).toBe(409);
  });
  test('IT-BILL-07: lọc hóa đơn theo kỳ', async () => {
    await request(app).post('/api/bills').set(auth()).send({ customerId: cid, month: '2026-08', oldIndex: 0, newIndex: 100 });
    await request(app).post('/api/bills').set(auth()).send({ customerId: cid, month: '2026-09', newIndex: 180 });
    const res = await request(app).get('/api/bills?month=2026-09').set(auth());
    expect(res.body).toHaveLength(1);
    expect(res.body[0].kwh).toBe(80);
  });
  test('IT-BILL-08: khách hàng không tồn tại -> 404', async () => {
    const res = await request(app).post('/api/bills').set(auth()).send({ customerId: 999, month: '2026-08', newIndex: 1 });
    expect(res.status).toBe(404);
  });
});

describe('IT-TAR: Biểu giá và tính nhanh', () => {
  test('IT-TAR-01: tính nhanh 100 kWh', async () => {
    const res = await request(app).post('/api/calculate').set('Authorization', `Bearer ${staffToken}`)
      .send({ kwh: '100', customerType: 'HO_GIA_DINH', householdCount: '1' });
    expect(res.status).toBe(200);
    expect(res.body.total).toBe(217836);
  });
  test('IT-TAR-02: tính nhanh với kWh "abc" -> 400', async () => {
    const res = await request(app).post('/api/calculate').set('Authorization', `Bearer ${staffToken}`)
      .send({ kwh: 'abc', customerType: 'HO_GIA_DINH' });
    expect(res.status).toBe(400);
    expect(res.body.code).toBe('INVALID_KWH');
  });
  test('IT-TAR-03: admin cập nhật biểu giá, hóa đơn mới dùng giá mới', async () => {
    const t = (await request(app).get('/api/tariff').set('Authorization', `Bearer ${adminToken}`)).body;
    t.tiers[0].price = 2000;
    const put = await request(app).put('/api/tariff').set('Authorization', `Bearer ${adminToken}`).send(t);
    expect(put.status).toBe(200);
    const calc = await request(app).post('/api/calculate').set('Authorization', `Bearer ${adminToken}`)
      .send({ kwh: 50, customerType: 'HO_GIA_DINH', householdCount: 1 });
    expect(calc.body.subtotal).toBe(100000);
  });
  test.each([
    ['đơn giá rỗng', (t) => { t.tiers[1].price = ''; }],
    ['VAT rỗng', (t) => { t.vatRate = ''; }],
    ['VAT null', (t) => { t.vatRate = null; }],
    ['VAT 30%', (t) => { t.vatRate = 0.3; }],
  ])('IT-TAR-04: biểu giá không hợp lệ (%s) -> 400', async (_n, mutate) => {
    const t = (await request(app).get('/api/tariff').set('Authorization', `Bearer ${adminToken}`)).body;
    mutate(t);
    const res = await request(app).put('/api/tariff').set('Authorization', `Bearer ${adminToken}`).send(t);
    expect(res.status).toBe(400);
  });
});
