'use strict';
const { validateRegister, validateCustomer, validateReading, toInt } = require('../../src/validators');

const validCustomer = {
  code: 'KH000001', name: 'Nguyễn Văn A', phone: '0912468357', address: 'Số 1 Nguyễn Trác, Yên Nghĩa, Hà Nội',
  type: 'HO_GIA_DINH', householdCount: 1, personCount: 0,
};

describe('UT-VAL-REG: validateRegister', () => {
  const ok = { username: 'user01', fullName: 'Trần Bình', password: 'Matkhau123', confirmPassword: 'Matkhau123' };
  test('hợp lệ', () => expect(validateRegister(ok)).toEqual([]));
  test.each([
    ['username 3 ký tự', { username: 'abc' }, 'Tên đăng nhập gồm'],
    ['username 31 ký tự', { username: 'a'.repeat(31) }, 'Tên đăng nhập gồm'],
    ['username có dấu cách', { username: 'user 01' }, 'Tên đăng nhập gồm'],
    ['username rỗng', { username: '' }, 'Tên đăng nhập không được để trống'],
    ['username bắt đầu bằng số', { username: '1user' }, 'bắt đầu bằng chữ cái'],
    ['username dành riêng', { username: 'admin' }, 'dành riêng'],
    ['họ tên rỗng', { fullName: '  ' }, 'Họ tên không được để trống'],
    ['họ tên 1 từ', { fullName: 'Bình' }, 'ít nhất họ và tên'],
    ['họ tên có số', { fullName: 'Trần Bình 2' }, 'chỉ được chứa chữ cái'],
    ['mật khẩu 7 ký tự', { password: 'Abc1234', confirmPassword: 'Abc1234' }, 'Mật khẩu phải từ 8 đến 50 ký tự'],
    ['mật khẩu không có chữ hoa', { password: 'matkhau123', confirmPassword: 'matkhau123' }, 'chữ hoa'],
    ['mật khẩu chứa tên đăng nhập', { password: 'User01abc', confirmPassword: 'User01abc' }, 'chứa tên đăng nhập'],
    ['xác nhận không khớp', { confirmPassword: 'Matkhau124' }, 'Mật khẩu xác nhận không khớp'],
    ['mật khẩu rỗng', { password: '', confirmPassword: '' }, 'Mật khẩu không được để trống'],
  ])('%s', (_n, patch, msg) => {
    const errors = validateRegister({ ...ok, ...patch });
    expect(errors.join('|')).toContain(msg);
  });
  test('biên hợp lệ: username 4 ký tự, mật khẩu 8 ký tự', () => {
    expect(validateRegister({ ...ok, username: 'abcd', password: 'Qwerty12', confirmPassword: 'Qwerty12' })).toEqual([]);
  });
});

describe('UT-VAL-CUS: validateCustomer', () => {
  test('hợp lệ (hộ gia đình)', () => expect(validateCustomer(validCustomer)).toEqual([]));
  test('chuẩn hóa dữ liệu khi hợp lệ', () => {
    const c = { ...validCustomer, code: 'kh000002', name: 'lê  thị   hoa', phone: '+84 912 468 357', address: 'số 1 nguyễn trác,yên nghĩa, ha noi' };
    expect(validateCustomer(c)).toEqual([]);
    expect(c).toMatchObject({ code: 'KH000002', name: 'Lê Thị Hoa', phone: '0912468357', address: 'Số 1 nguyễn trác, Yên nghĩa, Hà Nội' });
  });
  test('hợp lệ (thuê nhà, 0 người)', () => {
    expect(validateCustomer({ ...validCustomer, type: 'THUE_NHA', personCount: 0 })).toEqual([]);
  });
  test.each([
    ['mã rỗng', { code: '' }],
    ['mã sai định dạng', { code: 'KH1' }],
    ['mã có dấu cách ở giữa', { code: 'KH 00001' }],
    ['tên 1 ký tự', { name: 'A' }],
    ['tên rỗng', { name: '' }],
    ['tên 101 ký tự', { name: 'a'.repeat(101) }],
    ['SĐT 9 số', { phone: '091246835' }],
    ['SĐT 11 số', { phone: '09124683571' }],
    ['SĐT không bắt đầu bằng 0', { phone: '1912468357' }],
    ['SĐT bắt đầu bằng 00', { phone: '0012468357' }],
    ['SĐT máy bàn', { phone: '0241234567' }],
    ['tên có số', { name: 'Nguyễn Văn 3' }],
    ['địa chỉ thiếu tỉnh', { address: 'Số 1 Nguyễn Trác, Hà Đông' }],
    ['mã KH000000', { code: 'KH000000' }],
    ['SĐT rỗng', { phone: '' }],
    ['địa chỉ 4 ký tự', { address: 'Hà N' }],
    ['địa chỉ rỗng', { address: '' }],
    ['địa chỉ 201 ký tự', { address: 'a'.repeat(201) }],
    ['số hộ = 0', { householdCount: 0 }],
    ['số hộ = 21', { householdCount: 21 }],
    ['số người = 101', { type: 'THUE_NHA', personCount: 101 }],
    ['số người âm', { type: 'THUE_NHA', personCount: -1 }],
    ['loại KH sai', { type: 'ABC' }],
  ])('không hợp lệ: %s', (_n, patch) => {
    expect(validateCustomer({ ...validCustomer, ...patch }).length).toBeGreaterThan(0);
  });
});

describe('UT-VAL-RD: validateReading', () => {
  test('hợp lệ', () => expect(validateReading({ month: '2026-09', oldIndex: 100, newIndex: 250 })).toEqual([]));
  test('biên: chỉ số mới = chỉ số cũ (0 kWh) hợp lệ', () => {
    expect(validateReading({ month: '2026-09', oldIndex: 100, newIndex: 100 })).toEqual([]);
  });
  test.each([
    ['chỉ số mới < cũ', { newIndex: 99 }, 'Chỉ số mới không được nhỏ hơn chỉ số cũ'],
    ['tháng 13', { month: '2026-13' }, 'YYYY-MM'],
    ['tháng 00', { month: '2026-00' }, 'YYYY-MM'],
    ['sai định dạng tháng', { month: '09/2026' }, 'YYYY-MM'],
    ['tháng rỗng', { month: '' }, 'không được để trống'],
    ['chỉ số cũ âm', { oldIndex: -1 }, 'Chỉ số cũ'],
    ['chỉ số mới vượt 99999999', { newIndex: 100000000 }, 'Chỉ số mới'],
    ['chỉ số mới không phải số', { newIndex: NaN }, 'Chỉ số mới'],
    ['kỳ trước năm 2000', { month: '1999-12' }, 'từ 2000-01'],
    ['kỳ sau tháng hiện tại', { month: '2099-01' }, 'không được sau tháng hiện tại'],
  ])('không hợp lệ: %s', (_n, patch, msg) => {
    const errors = validateReading({ month: '2026-09', oldIndex: 100, newIndex: 250, ...patch });
    expect(errors.join('|')).toContain(msg);
  });
});

describe('UT-VAL-INT: toInt', () => {
  test.each([
    ['12', 12], [' 7 ', 7], [5, 5], ['-3', -3],
  ])('toInt(%p) = %p', (input, out) => expect(toInt(input)).toBe(out));
  test.each(['1.5', 'abc', '', null, undefined, 2.5, '1e3'])('toInt(%p) = NaN', (input) => {
    expect(toInt(input)).toBeNaN();
  });
});
