'use strict';
const {
  calculateBill, getNormMultiplier, validateTariff, BillingError, CUSTOMER_TYPES,
} = require('../../src/billing/calculator');
const { DEFAULT_TARIFF } = require('../../src/billing/tariff');

const tariff = DEFAULT_TARIFF;
const HH = CUSTOMER_TYPES.HOUSEHOLD;
const RENTER = CUSTOMER_TYPES.RENTER;

/** Giá trị mong đợi được tính tay từ biểu giá QĐ 1279/QĐ-BCT (xem Test Case UT-BVA). */
describe('UT-BVA: Phân tích giá trị biên của sản lượng kWh (hộ gia đình, 1 hộ)', () => {
  test.each([
    // [ID, kWh, tiền chưa thuế, VAT, tổng]
    ['UT-BVA-01', 0, 0, 0, 0],
    ['UT-BVA-02', 1, 1984, 159, 2143],
    ['UT-BVA-03', 49, 97216, 7777, 104993],
    ['UT-BVA-04', 50, 99200, 7936, 107136],
    ['UT-BVA-05', 51, 101250, 8100, 109350],
    ['UT-BVA-06', 99, 199650, 15972, 215622],
    ['UT-BVA-07', 100, 201700, 16136, 217836],
    ['UT-BVA-08', 101, 204080, 16326, 220406],
    ['UT-BVA-09', 200, 439700, 35176, 474876],
    ['UT-BVA-10', 201, 442698, 35416, 478114],
    ['UT-BVA-11', 300, 739500, 59160, 798660],
    ['UT-BVA-12', 301, 742850, 59428, 802278],
    ['UT-BVA-13', 400, 1074500, 85960, 1160460],
    ['UT-BVA-14', 401, 1077960, 86237, 1164197],
    ['UT-BVA-15', 1000000, 3459690500, 276775240, 3736465740],
  ])('%s: %i kWh', (_id, kwh, subtotal, vat, total) => {
    const r = calculateBill({ kwh, customerType: HH, householdCount: 1, tariff });
    expect(r.subtotal).toBe(subtotal);
    expect(r.vat).toBe(vat);
    expect(r.total).toBe(total);
  });

  test.each([
    ['UT-BVA-16', -1],
    ['UT-BVA-17', 1000001],
  ])('%s: %i kWh nằm ngoài miền hợp lệ -> INVALID_KWH', (_id, kwh) => {
    expect(() => calculateBill({ kwh, tariff })).toThrow(expect.objectContaining({ code: 'INVALID_KWH' }));
  });
});

describe('UT-EP: Phân vùng tương đương', () => {
  test('UT-EP-01: kWh là số thập phân (1.5) -> lỗi', () => {
    expect(() => calculateBill({ kwh: 1.5, tariff })).toThrow(BillingError);
  });
  test('UT-EP-02: kWh là chuỗi ("100") -> lỗi', () => {
    expect(() => calculateBill({ kwh: '100', tariff })).toThrow(expect.objectContaining({ code: 'INVALID_KWH' }));
  });
  test('UT-EP-03: kWh là NaN -> lỗi', () => {
    expect(() => calculateBill({ kwh: NaN, tariff })).toThrow(expect.objectContaining({ code: 'INVALID_KWH' }));
  });
  test('UT-EP-04: loại khách hàng không hợp lệ -> INVALID_CUSTOMER_TYPE', () => {
    expect(() => calculateBill({ kwh: 10, customerType: 'KINH_DOANH', tariff }))
      .toThrow(expect.objectContaining({ code: 'INVALID_CUSTOMER_TYPE' }));
  });
  test.each([0, 21, 1.5])('UT-EP-05: số hộ = %p -> INVALID_HOUSEHOLD_COUNT', (n) => {
    expect(() => calculateBill({ kwh: 10, customerType: HH, householdCount: n, tariff }))
      .toThrow(expect.objectContaining({ code: 'INVALID_HOUSEHOLD_COUNT' }));
  });
  test.each([-1, 101, 2.5])('UT-EP-06: số người thuê = %p -> INVALID_PERSON_COUNT', (n) => {
    expect(() => calculateBill({ kwh: 10, customerType: RENTER, personCount: n, tariff }))
      .toThrow(expect.objectContaining({ code: 'INVALID_PERSON_COUNT' }));
  });
});

describe('UT-DT: Bảng quyết định loại khách hàng × định mức', () => {
  test('UT-DT-01: hộ gia đình, 2 hộ chung công tơ, 150 kWh -> bậc 1 = 100 kWh', () => {
    const r = calculateBill({ kwh: 150, customerType: HH, householdCount: 2, tariff });
    expect(r.breakdown).toEqual([
      { tier: 1, kwh: 100, price: 1984, amount: 198400 },
      { tier: 2, kwh: 50, price: 2050, amount: 102500 },
    ]);
    expect(r.subtotal).toBe(300900);
  });
  test('UT-DT-02: thuê nhà 4 người = 1 hộ, cho kết quả giống hộ gia đình 1 hộ', () => {
    const a = calculateBill({ kwh: 250, customerType: RENTER, personCount: 4, tariff });
    const b = calculateBill({ kwh: 250, customerType: HH, householdCount: 1, tariff });
    expect(a.total).toBe(b.total);
  });
  test('UT-DT-03: thuê nhà 2 người (1/2 định mức), 100 kWh', () => {
    const r = calculateBill({ kwh: 100, customerType: RENTER, personCount: 2, tariff });
    expect(r.subtotal).toBe(219850); // 25*1984 + 25*2050 + 50*2380
  });
  test('UT-DT-04: thuê nhà 1 người (1/4 định mức, làm tròn 12.5 -> 13 kWh), 20 kWh', () => {
    const r = calculateBill({ kwh: 20, customerType: RENTER, personCount: 1, tariff });
    expect(r.breakdown.map((b) => b.kwh)).toEqual([13, 7]);
    expect(r.subtotal).toBe(40142);
  });
  test('UT-DT-05: thuê nhà không kê khai (0 người) -> đồng giá 2.380 đ/kWh', () => {
    const r = calculateBill({ kwh: 100, customerType: RENTER, personCount: 0, tariff });
    expect(r.breakdown).toEqual([{ tier: 0, kwh: 100, price: 2380, amount: 238000 }]);
    expect(r.total).toBe(257040);
  });
});

/**
 * Kiểm thử hộp trắng cho calculateBill (xem CFG trong tài liệu Test Plan).
 * Mỗi test phủ một đường đi độc lập (basis path).
 */
describe('UT-WB: Kiểm thử hộp trắng - basis paths của calculateBill', () => {
  test('UT-WB-01 (P1): kWh không hợp lệ -> ném lỗi ngay tại nút kiểm tra đầu vào', () => {
    expect(() => calculateBill({ kwh: -5, tariff })).toThrow(BillingError);
  });
  test('UT-WB-02 (P2): không kê khai + kWh = 0 -> nhánh đồng giá, không thêm dòng chi tiết', () => {
    const r = calculateBill({ kwh: 0, customerType: RENTER, personCount: 0, tariff });
    expect(r.breakdown).toEqual([]);
    expect(r.total).toBe(0);
  });
  test('UT-WB-03 (P3): không kê khai + kWh > 0 -> nhánh đồng giá có dòng chi tiết', () => {
    const r = calculateBill({ kwh: 10, customerType: RENTER, personCount: 0, tariff });
    expect(r.breakdown).toHaveLength(1);
  });
  test('UT-WB-04 (P4): bậc thang, kWh = 0 -> vòng lặp không thực hiện lần nào', () => {
    const r = calculateBill({ kwh: 0, tariff });
    expect(r.breakdown).toEqual([]);
  });
  test('UT-WB-05 (P5): bậc thang, dừng giữa chừng tại bậc 3 (remaining = 0)', () => {
    const r = calculateBill({ kwh: 150, tariff });
    expect(r.breakdown.map((b) => b.tier)).toEqual([1, 2, 3]);
  });
  test('UT-WB-06 (P6): bậc thang, đi qua bậc cuối không giới hạn (width = null)', () => {
    const r = calculateBill({ kwh: 500, tariff });
    expect(r.breakdown[5]).toEqual({ tier: 6, kwh: 100, price: 3460, amount: 346000 });
    expect(r.subtotal).toBe(1420500);
  });
  test('UT-WB-07 (P7): bậc có cap = 0 (used = 0) -> bỏ qua bậc đó, nhánh used > 0 = false', () => {
    const custom = { ...tariff, tiers: [{ width: 1, price: 1000 }, { width: null, price: 2000 }] };
    // 1 người thuê: cap bậc 1 = round(1 * 0.25) = 0
    const r = calculateBill({ kwh: 3, customerType: RENTER, personCount: 1, tariff: custom });
    expect(r.breakdown).toEqual([{ tier: 2, kwh: 3, price: 2000, amount: 6000 }]);
  });
});

describe('UT-FN: Các hàm phụ trợ', () => {
  test('UT-FN-01: getNormMultiplier trả về đúng hệ số', () => {
    expect(getNormMultiplier(HH, 3, 0)).toBe(3);
    expect(getNormMultiplier(RENTER, 1, 6)).toBe(1.5);
    expect(getNormMultiplier(RENTER, 1, 0)).toBeNull();
  });
  test.each([
    ['tariff null', null],
    ['không có bậc', { ...tariff, tiers: [] }],
    ['đơn giá âm', { ...tariff, tiers: [{ width: 50, price: -1 }, { width: null, price: 100 }] }],
    ['bậc cuối có giới hạn', { ...tariff, tiers: [{ width: 50, price: 100 }, { width: 50, price: 200 }] }],
    ['bậc giữa width = 0', { ...tariff, tiers: [{ width: 0, price: 100 }, { width: null, price: 200 }] }],
    ['VAT > 20%', { ...tariff, vatRate: 0.25 }],
    ['VAT âm', { ...tariff, vatRate: -0.01 }],
    ['VAT không phải số', { ...tariff, vatRate: '8' }],
    ['VAT NaN (hồi quy BUG-01)', { ...tariff, vatRate: NaN }],
    ['giá không kê khai = 0', { ...tariff, undeclaredPrice: 0 }],
  ])('UT-FN-02: validateTariff từ chối biểu giá: %s', (_name, t) => {
    expect(() => validateTariff(t)).toThrow(expect.objectContaining({ code: 'INVALID_TARIFF' }));
  });
  test('UT-FN-03: validateTariff chấp nhận biểu giá mặc định', () => {
    expect(() => validateTariff(tariff)).not.toThrow();
  });
  test('UT-FN-04: VAT = 0% -> tổng bằng tiền chưa thuế', () => {
    const r = calculateBill({ kwh: 100, tariff: { ...tariff, vatRate: 0 } });
    expect(r.total).toBe(r.subtotal);
  });
});
