'use strict';
const R = require('../../public/rules');

describe('UT-PHONE: Số điện thoại di động', () => {
  test.each([
    ['0912468357', '0912468357', 'Vinaphone'],
    ['0386 452 917', '0386452917', 'Viettel'],
    ['+84 912 468 357', '0912468357', 'Vinaphone'],
    ['84912468357', '0912468357', 'Vinaphone'],
    ['0912.468.357', '0912468357', 'Vinaphone'],
    ['(091) 246-8357', '0912468357', 'Vinaphone'],
    ['0708135792', '0708135792', 'MobiFone'],
    ['0526813579', '0526813579', 'Vietnamobile'],
    ['0597135792', '0597135792', 'Gmobile'],
    ['0871357924', '0871357924', 'iTel'],
  ])('hợp lệ: %s -> %s (%s)', (input, norm, carrier) => {
    const r = R.analyzePhone(input);
    expect(r).toMatchObject({ ok: true, normalized: norm, carrier });
  });
  test.each([
    ['', 'EMPTY'],
    ['0012468357', 'DOUBLE_ZERO'],
    ['0012345', 'DOUBLE_ZERO'],
    ['1912468357', 'NO_LEADING_ZERO'],
    ['0241234567', 'LANDLINE'],
    ['02438681234', 'LANDLINE'],
    ['01686135792', 'OLD_11_DIGIT'],
    ['091246835', 'LENGTH'],
    ['09124683571', 'LENGTH'],
    ['0612468357', 'UNKNOWN_PREFIX'],
    ['0802468357', 'UNKNOWN_PREFIX'],
    ['0911111111', 'FAKE_REPEAT'],
    ['0901234567', 'FAKE_SEQUENCE'],
    ['0987654321', 'FAKE_SEQUENCE'],
    ['09a2468357', 'INVALID_CHAR'],
    ['+1 912 468 357', 'FOREIGN'],
    ['0912--468357', 'BAD_FORMAT'],
    ['+84+912468357', 'INVALID_CHAR'],
    ['(091 2468357', 'BAD_FORMAT'],
  ])('không hợp lệ: %p -> %s', (input, code) => {
    expect(R.analyzePhone(input).code).toBe(code);
  });
});

describe('UT-NAME: Họ tên', () => {
  test.each([
    ['nguyễn   văn an', 'Nguyễn Văn An'],
    ['  TRẦN THỊ BÌNH ', 'Trần Thị Bình'],
    ['Lê B', 'Lê B'],
  ])('hợp lệ và chuẩn hóa: %p -> %p', (input, out) => {
    expect(R.checkPersonName(input, 'Tên')).toMatchObject({ ok: true, value: out });
  });
  test.each([
    ['', 'không được để trống'],
    ['An', 'ít nhất họ và tên'],
    ['Nguyễn Văn A1', 'chỉ được chứa chữ cái'],
    ['Nguyễn@Văn', 'chỉ được chứa chữ cái'],
    ['<img src=x>', 'chỉ được chứa chữ cái'],
    ['Nguyễnnn Văn', '3 chữ cái giống nhau'],
    ['Nguyễn Aaaaaaaaaaaaaaaab', 'từ quá dài'],
    ['A B C D E F G H I J K', 'tối đa 10 từ'],
    ['a'.repeat(50) + ' ' + 'b'.repeat(51), 'từ 2 đến 100 ký tự'],
  ])('không hợp lệ: %p', (input, msg) => {
    const r = R.checkPersonName(input, 'Tên');
    expect(r.ok).toBe(false);
    expect(r.errors.join('|')).toContain(msg);
  });
});

describe('UT-ADDR: Địa chỉ', () => {
  test.each([
    ['Số 1 Nguyễn Trác, Yên Nghĩa, Hà Nội', 'Số 1 Nguyễn Trác, Yên Nghĩa, Hà Nội'],
    ['số 1   nguyễn trác ,yên nghĩa,hà nội', 'Số 1   nguyễn trác, Yên nghĩa, Hà Nội'.replace(/ {2,}/g, ' ')],
    ['Thôn 3, Xã Phù Đổng, tp.hcm', 'Thôn 3, Xã Phù Đổng, TP. Hồ Chí Minh'],
    ['12/4 Lê Lợi, Phường Bến Thành, Thành phố Hồ Chí Minh', '12/4 Lê Lợi, Phường Bến Thành, TP. Hồ Chí Minh'],
    ['Tổ 2, Phường Phan Đình Phùng, tỉnh Thái Nguyên', 'Tổ 2, Phường Phan Đình Phùng, Thái Nguyên'],
    ['Số 5 Trần Phú, Phường Vĩnh Ninh, Thừa Thiên Huế', 'Số 5 Trần Phú, Phường Vĩnh Ninh, Huế'],
    ['Ấp Tân Hòa, Xã Thới Sơn, Dak Lak', 'Ấp Tân Hòa, Xã Thới Sơn, Đắk Lắk'],
  ])('hợp lệ và chuẩn hóa: %p', (input, out) => {
    expect(R.checkAddress(input)).toMatchObject({ ok: true, value: out });
  });
  test.each([
    ['', 'không được để trống'],
    ['1, ab, HN', 'từ 10 đến 200'],
    ['Số 1 Nguyễn Trác, Hà Nội', 'ít nhất 3 phần'],
    ['Số 1 Nguyễn Trác Hà Đông Hà Nội', 'ít nhất 3 phần'],
    ['Nhà A Nguyễn Trác, Yên Nghĩa, Hà Nội', 'Phần đầu địa chỉ phải có số nhà'],
    ['Số 1 Nguyễn Trác, Yên Nghĩa, Bắc Giang', 'không phải tỉnh/thành phố hợp lệ'],
    ['Số 1 Nguyễn Trác, Yên Nghĩa, Hà Nội <script>', 'ký tự không hợp lệ'],
    ['Số 1 Nguyễn Trác; Yên Nghĩa; Hà Nội', 'ký tự không hợp lệ'],
    ['Số 1 Nguyễn Trác,, Yên Nghĩa, Hà Nội', 'Mỗi phần của địa chỉ'],
    ['Số 1-- Nguyễn Trác, Yên Nghĩa, Hà Nội', 'dấu câu liên tiếp'],
    ['123456789, 123, 456', 'phải chứa chữ cái'],
    ['Số 1 ' + 'a'.repeat(200) + ', Yên Nghĩa, Hà Nội', 'từ 10 đến 200'],
  ])('không hợp lệ: %p', (input, msg) => {
    const r = R.checkAddress(input);
    expect(r.ok).toBe(false);
    expect(r.errors.join('|')).toContain(msg);
  });
  test('đủ 34 tỉnh, thành phố và nhận dạng tên viết tắt', () => {
    expect(R.PROVINCES).toHaveLength(34);
    expect(R.matchProvince('TP HCM')).toBe('Hồ Chí Minh');
    expect(R.matchProvince('Thành phố Đà Nẵng')).toBe('Đà Nẵng');
    expect(R.matchProvince('ha noi')).toBe('Hà Nội');
    expect(R.matchProvince('Hà Tây')).toBeNull();
  });
});

describe('UT-CODE: Mã khách hàng', () => {
  test('chữ thường được chuyển thành chữ hoa', () => expect(R.checkCustomerCode(' kh000123 ')).toMatchObject({ ok: true, value: 'KH000123' }));
  test.each(['', 'KH1', 'KH0000001', 'AB000001', 'KH00000A', 'KH000000'])('không hợp lệ: %p', (v) => {
    expect(R.checkCustomerCode(v).ok).toBe(false);
  });
});

describe('UT-ACC: Tên đăng nhập và mật khẩu', () => {
  test.each(['user01', 'nguyen_van_an', 'abcd'])('tên đăng nhập hợp lệ: %s', (v) => expect(R.checkUsername(v).ok).toBe(true));
  test.each([
    ['abc', '4-30 ký tự'], ['1user', 'bắt đầu bằng chữ cái'], ['_user', 'bắt đầu bằng chữ cái'],
    ['user__01', '2 dấu gạch dưới'], ['user_', 'kết thúc bằng dấu gạch dưới'], ['Admin', 'dành riêng'],
    ['user 01', '4-30 ký tự'], ['người_dùng', '4-30 ký tự'],
  ])('tên đăng nhập không hợp lệ: %p', (v, msg) => expect(R.checkUsername(v).errors.join('|')).toContain(msg));
  test('mật khẩu hợp lệ', () => expect(R.checkPassword('Matkhau123', 'user01').ok).toBe(true));
  test.each([
    ['Abc1234', '8 đến 50'], ['A1' + 'b'.repeat(49), '8 đến 50'], ['matkhau123', 'chữ hoa'], ['MATKHAU123', 'chữ thường'],
    ['Matkhauabc', 'chữ số'], ['Mat khau 123', 'dấu cách'], ['User01Pass', 'chứa tên đăng nhập'], ['', 'không được để trống'],
  ])('mật khẩu không hợp lệ: %p', (v, msg) => expect(R.checkPassword(v, 'user01').errors.join('|')).toContain(msg));
});
