'use strict';
/**
 * Kiểm thử hiệu năng đơn giản (không cần công cụ ngoài).
 * Gửi N yêu cầu tính tiền với độ đồng thời C tới server đang chạy.
 * Chạy: node tests/perf/perf.js [baseUrl] [N] [C]
 */
const BASE = process.argv[2] || 'http://localhost:3000';
const N = Number(process.argv[3] || 1000);
const C = Number(process.argv[4] || 20);

async function main() {
  const login = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'admin', password: 'Admin@123' }),
  }).then((r) => r.json());
  const headers = { 'Content-Type': 'application/json', Authorization: `Bearer ${login.token}` };

  const times = [];
  let errors = 0;
  let sent = 0;
  const start = Date.now();
  async function worker() {
    while (sent < N) {
      sent++;
      const kwh = Math.floor(Math.random() * 1000);
      const t0 = performance.now();
      const res = await fetch(`${BASE}/api/calculate`, {
        method: 'POST', headers, body: JSON.stringify({ kwh, customerType: 'HO_GIA_DINH', householdCount: 1 }),
      });
      await res.json();
      times.push(performance.now() - t0);
      if (!res.ok) errors++;
    }
  }
  await Promise.all(Array.from({ length: C }, worker));
  const total = (Date.now() - start) / 1000;
  times.sort((a, b) => a - b);
  const pct = (p) => times[Math.min(times.length - 1, Math.floor(times.length * p))].toFixed(1);
  console.log(JSON.stringify({
    requests: N, concurrency: C, errors, durationSec: total,
    throughputRps: Math.round(N / total), avgMs: (times.reduce((a, b) => a + b, 0) / N).toFixed(1),
    p50Ms: pct(0.5), p95Ms: pct(0.95), maxMs: times[times.length - 1].toFixed(1),
  }, null, 2));
}
main().catch((e) => { console.error(e); process.exit(1); });
