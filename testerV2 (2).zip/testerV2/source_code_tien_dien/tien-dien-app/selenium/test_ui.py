"""
Kiểm thử tự động giao diện web bằng Selenium WebDriver (Khóa 4).
Mã test (ST-xx) tương ứng cột "Automation" trong file Test Cases.
Chạy:  cd selenium && pytest -v
"""
import uuid

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select


def unique_code():
    return "KH" + str(uuid.uuid4().int)[:6]


# ---------------- Đăng nhập / Đăng ký ----------------
def test_ST01_login_success(ui):
    ui.login_admin()
    assert "Quản trị" in ui.text_of("#current-user")


def test_ST02_login_wrong_password(ui):
    ui.login("admin", "saimatkhau1")
    assert ui.wait_text("#login-error", "không đúng") == "Tên đăng nhập hoặc mật khẩu không đúng"


def test_ST03_login_empty_fields(ui):
    ui.click("#login-btn")
    assert "Vui lòng nhập" in ui.wait_text("#login-error", "Vui lòng nhập")


def test_ST04_register_then_login(ui):
    username = "sv_" + uuid.uuid4().hex[:8]
    ui.click("#goto-register")
    ui.type("#reg-username", username)
    ui.type("#reg-fullname", "Sinh viên Test")
    ui.type("#reg-password", "Matkhau123")
    ui.type("#reg-confirm", "Matkhau123")
    ui.click("#reg-btn")
    assert "thành công" in ui.wait_text("#reg-message", "thành công")
    ui.click("#goto-login")
    ui.login(username, "Matkhau123")
    assert "Nhân viên" in ui.wait_text("#current-user", "Nhân viên")


def test_ST05_register_password_mismatch(ui):
    ui.click("#goto-register")
    ui.type("#reg-username", "sv_mismatch")
    ui.type("#reg-fullname", "Nguyễn Văn Test")
    ui.type("#reg-password", "Matkhau123")
    ui.type("#reg-confirm", "Matkhau124")
    ui.click("#reg-btn")
    assert "không khớp" in ui.wait_text("#reg-message", "không khớp")


# ---------------- Tính nhanh ----------------
def test_ST06_calculate_100_kwh(ui):
    ui.login_staff()
    ui.type("#calc-kwh", "100")
    ui.click("#calc-btn")
    assert ui.wait_text("#calc-total", "đ") == "217.836 đ"
    rows = ui.d.find_elements(By.CSS_SELECTOR, "#calc-breakdown tbody tr")
    assert len(rows) == 2


def test_ST07_calculate_invalid_kwh(ui):
    ui.login_staff()
    ui.type("#calc-kwh", "abc")
    ui.click("#calc-btn")
    assert "Sản lượng điện phải là số nguyên" in ui.wait_text("#calc-error", "Sản lượng")
    assert not ui.d.find_element(By.ID, "calc-result").is_displayed()


def test_ST08_calculate_renter_undeclared(ui):
    ui.login_staff()
    Select(ui.el("#calc-type")).select_by_value("THUE_NHA")
    ui.type("#calc-persons", "0")
    ui.type("#calc-kwh", "100")
    ui.click("#calc-btn")
    assert ui.wait_text("#calc-total", "đ") == "257.040 đ"


# ---------------- Khách hàng ----------------
def test_ST09_add_customer(ui):
    ui.login_staff()
    code = unique_code()
    ui.add_customer(code, "Nguyễn Văn Selenium")
    assert "Thêm khách hàng thành công" in ui.wait_text("#cus-message", "thành công")
    ui.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, f'#cus-table tr[data-code="{code}"]')))


def test_ST10_add_customer_invalid_phone(ui):
    ui.login_staff()
    ui.add_customer(unique_code(), "Khách Lỗi Số", phone="0012468357")
    assert "không được bắt đầu bằng 00" in ui.wait_text("#cus-message", "Số điện thoại")


def test_ST11_search_customer(ui):
    ui.login_staff()
    code = unique_code()
    ui.add_customer(code, "Trần Thị Tìm Kiếm")
    ui.wait_text("#cus-message", "thành công")
    ui.type("#cus-search", "Tìm Kiếm")
    ui.click("#cus-search-btn")
    ui.wait.until(lambda d: len(d.find_elements(By.CSS_SELECTOR, "#cus-table tbody tr[data-code]")) == 1)
    assert code in ui.text_of("#cus-table tbody")


def test_ST12_delete_customer_with_confirm(ui):
    ui.login_staff()
    code = unique_code()
    ui.add_customer(code, "Khách Cần Xóa")
    row = ui.el(f'#cus-table tr[data-code="{code}"]')
    row.find_element(By.CSS_SELECTOR, ".btn-delete").click()
    alert = ui.wait.until(EC.alert_is_present())
    assert "chắc muốn xóa" in alert.text
    alert.accept()
    assert "Xóa khách hàng thành công" in ui.wait_text("#cus-message", "Xóa")
    ui.wait.until(EC.invisibility_of_element_located((By.CSS_SELECTOR, f'#cus-table tr[data-code="{code}"]')))


# ---------------- Ghi chỉ số & Hóa đơn ----------------
def _prepare_bill_customer(ui):
    code = unique_code()
    ui.add_customer(code, "Khách Hóa Đơn")
    ui.wait_text("#cus-message", "thành công")
    ui.click("#nav-bills")
    ui.wait.until(lambda d: len(d.find_elements(By.CSS_SELECTOR, "#bill-customer option")) > 1)
    Select(ui.el("#bill-customer")).select_by_visible_text(f"{code} - Khách Hóa Đơn")
    return code


def test_ST13_create_bill_and_next_period(ui):
    ui.login_staff()
    code = _prepare_bill_customer(ui)
    ui.type("#bill-month", "2026-08")
    ui.type("#bill-old", "1000")
    ui.type("#bill-new", "1150")
    ui.click("#bill-save-btn")
    msg = ui.wait_text("#bill-message", "thành công")
    assert "150 kWh" in msg and "346.356 đ" in msg
    # Kỳ sau: chỉ số cũ tự động = 1150 và không cho sửa
    ui.wait.until(lambda d: d.find_element(By.ID, "bill-old").get_attribute("value") == "1150")
    assert ui.el("#bill-old").get_attribute("readonly") is not None
    assert code in ui.text_of("#bill-table tbody")


def test_ST14_bill_new_index_less_than_old(ui):
    ui.login_staff()
    _prepare_bill_customer(ui)
    ui.type("#bill-month", "2026-08")
    ui.type("#bill-old", "500")
    ui.type("#bill-new", "499")
    ui.click("#bill-save-btn")
    assert "Chỉ số mới không được nhỏ hơn chỉ số cũ" in ui.wait_text("#bill-message", "Chỉ số mới")


def test_ST15_pay_bill(ui):
    ui.login_staff()
    code = _prepare_bill_customer(ui)
    ui.type("#bill-month", "2026-09")
    ui.type("#bill-new", "80")
    ui.click("#bill-save-btn")
    ui.wait_text("#bill-message", "thành công")
    pay_btn = (By.XPATH, f"//table[@id='bill-table']//tr[td[text()='{code}']]//button[contains(@class,'btn-pay')]")
    ui.wait.until(EC.element_to_be_clickable(pay_btn)).click()
    status = (By.XPATH, f"//table[@id='bill-table']//tr[td[text()='{code}']]/td[contains(@class,'status')]")
    ui.wait.until(EC.text_to_be_present_in_element(status, "Đã thanh toán"))


# ---------------- Biểu giá & phân quyền ----------------
def test_ST16_staff_cannot_edit_tariff(ui):
    ui.login_staff()
    ui.click("#nav-tariff")
    ui.visible("#tariff-table tbody tr")
    assert not ui.d.find_element(By.ID, "tariff-save-btn").is_displayed()
    assert ui.d.find_element(By.ID, "tariff-vat").get_attribute("disabled") is not None


def test_ST17_admin_update_tariff_invalid_vat(ui):
    ui.login_admin()
    ui.click("#nav-tariff")
    ui.visible("#tariff-table tbody tr")
    ui.type("#tariff-vat", "abc")
    ui.click("#tariff-save-btn")
    assert "VAT" in ui.wait_text("#tariff-message", "VAT")


def test_ST18_logout(ui):
    ui.login_admin()
    ui.click("#logout-btn")
    ui.visible("#page-login")
    assert not ui.d.find_element(By.ID, "page-app").is_displayed()


# ---------------- Bổ sung (vòng 2) ----------------
def test_ST19_search_no_result(ui):
    ui.login_staff()
    ui.click("#nav-customers")
    ui.type("#cus-search", "khong-ton-tai-xyz")
    ui.click("#cus-search-btn")
    assert "Không có khách hàng phù hợp" in ui.wait_text("#cus-table tbody", "Không có khách hàng phù hợp")


def test_ST20_cancel_delete_keeps_customer(ui):
    ui.login_staff()
    code = unique_code()
    ui.add_customer(code, "Khách Không Xóa")
    row = ui.el(f'#cus-table tr[data-code="{code}"]')
    row.find_element(By.CSS_SELECTOR, ".btn-delete").click()
    ui.wait.until(EC.alert_is_present()).dismiss()
    assert ui.d.find_elements(By.CSS_SELECTOR, f'#cus-table tr[data-code="{code}"]')


def test_ST21_edit_customer(ui):
    ui.login_staff()
    code = unique_code()
    ui.add_customer(code, "Tên Cũ")
    ui.wait_text("#cus-message", "thành công")
    ui.el(f'#cus-table tr[data-code="{code}"]').find_element(By.CSS_SELECTOR, ".btn-edit").click()
    assert ui.el("#cus-code").get_attribute("disabled") is not None
    ui.type("#cus-name", "Tên Mới")
    ui.click("#cus-save-btn")
    assert "Cập nhật khách hàng thành công" in ui.wait_text("#cus-message", "Cập nhật")
    ui.wait.until(lambda d: "Tên Mới" in d.find_element(By.CSS_SELECTOR, f'#cus-table tr[data-code="{code}"]').text)


def test_ST22_xss_payload_rejected(ui):
    ui.login_staff()
    code = unique_code()
    ui.add_customer(code, "<img src=x onerror=alert(1)>")
    assert "chỉ được chứa chữ cái" in ui.wait_text("#cus-message", "chữ cái")
    assert not ui.d.find_elements(By.CSS_SELECTOR, f'#cus-table tr[data-code="{code}"]')
    assert not ui.d.find_elements(By.CSS_SELECTOR, "#cus-table img")


# ---------------- Bổ sung (vòng 3 – ràng buộc dữ liệu) ----------------
def test_ST23_live_hint_phone_and_address(ui):
    ui.login_staff()
    ui.click("#nav-customers")
    ui.type("#cus-phone", "0012468357")
    assert "không được bắt đầu bằng 00" in ui.wait_text("#cus-phone-hint", "00")
    ui.type("#cus-phone", "0912468357")
    assert "Vinaphone" in ui.wait_text("#cus-phone-hint", "Vinaphone")
    ui.type("#cus-address", "Số 1 Nguyễn Trác, Hà Đông")
    assert "ít nhất 3 phần" in ui.wait_text("#cus-address-hint", "3 phần")
    ui.type("#cus-phone", "abc")
    assert ui.el("#cus-phone").get_attribute("value") == ""


def test_ST24_normalize_on_blur_and_save(ui):
    ui.login_staff()
    code = unique_code()
    ui.add_customer(code.lower(), "  lê   thị hoa ", phone="+84 98 246 1357", address="số 5 lê lợi,phường bến thành,tp hcm")
    assert "thành công" in ui.wait_text("#cus-message", "thành công")
    row = ui.el(f'#cus-table tr[data-code="{code}"]').text
    assert "Lê Thị Hoa" in row and "0982461357" in row and "TP. Hồ Chí Minh" in row


def test_ST25_duplicate_phone_rejected(ui):
    ui.login_staff()
    phone = ui.random_phone()
    code1 = unique_code()
    ui.add_customer(code1, "Phạm Văn Một", phone=phone)
    ui.wait_text("#cus-message", "thành công")
    ui.add_customer(unique_code(), "Phạm Văn Hai", phone=phone)
    assert code1 in ui.wait_text("#cus-message", "đã được dùng")
