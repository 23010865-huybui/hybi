"""
Đo hiệu năng phía giao diện (NFR-P04, NFR-P05) bằng Selenium.
Yêu cầu: server đang chạy tại BASE_URL (mặc định http://localhost:3000).
Chạy: python perf_ui.py
"""
import os
import statistics
import time

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

BASE_URL = os.environ.get("BASE_URL", "http://localhost:3000")
RUNS = 10

opts = webdriver.ChromeOptions()
for a in ["--headless=new", "--no-sandbox", "--window-size=1366,900"]:
    opts.add_argument(a)
if os.environ.get("CHROME_BINARY"):
    opts.binary_location = os.environ["CHROME_BINARY"]
service = Service(os.environ["CHROMEDRIVER"]) if os.environ.get("CHROMEDRIVER") else Service()
d = webdriver.Chrome(service=service, options=opts)
wait = WebDriverWait(d, 10)

loads = []
for _ in range(RUNS):
    d.get(BASE_URL)
    wait.until(EC.visibility_of_element_located((By.ID, "login-btn")))
    t = d.execute_script("const n=performance.getEntriesByType('navigation')[0]; return n.loadEventEnd - n.startTime;")
    loads.append(t)

d.find_element(By.ID, "login-username").send_keys("admin")
d.find_element(By.ID, "login-password").send_keys("Admin@123")
d.find_element(By.ID, "login-btn").click()
wait.until(EC.visibility_of_element_located((By.ID, "calc-kwh")))
clicks = []
for i in range(RUNS):
    box = d.find_element(By.ID, "calc-kwh")
    box.clear()
    box.send_keys(str(100 + i * 37))
    t0 = time.perf_counter()
    d.find_element(By.ID, "calc-btn").click()
    wait.until(EC.visibility_of_element_located((By.ID, "calc-result")))
    clicks.append((time.perf_counter() - t0) * 1000)
d.quit()
print(f"Tải trang đăng nhập ({RUNS} lần): TB {statistics.mean(loads):.0f} ms, lớn nhất {max(loads):.0f} ms")
print(f"Nhấn 'Tính tiền' -> hiện kết quả ({RUNS} lần): TB {statistics.mean(clicks):.0f} ms, lớn nhất {max(clicks):.0f} ms")
