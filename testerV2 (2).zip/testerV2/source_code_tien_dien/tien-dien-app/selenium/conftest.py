"""
Cấu hình chung cho bộ kiểm thử Selenium.

- Tự khởi động server Node.js với một CSDL tạm (sạch) trên cổng 3100.
- Biến môi trường tùy chọn:
    HEADLESS=0          -> mở trình duyệt có giao diện để quan sát (mặc định chạy ẩn)
    CHROME_BINARY=...   -> đường dẫn Chrome/Chromium (nếu không dùng Chrome mặc định)
    CHROMEDRIVER=...    -> đường dẫn chromedriver (mặc định Selenium Manager tự tải)
"""
import os
import random
import subprocess
import tempfile
import time
import urllib.request

import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

PORT = int(os.environ.get("TEST_PORT", "3100"))
BASE_URL = f"http://localhost:{PORT}"
PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


@pytest.fixture(scope="session")
def server():
    db_file = os.path.join(tempfile.mkdtemp(), "selenium.sqlite")
    env = {**os.environ, "PORT": str(PORT), "DB_FILE": db_file}
    proc = subprocess.Popen(["node", "server.js"], cwd=PROJECT_DIR, env=env,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(50):
        try:
            urllib.request.urlopen(BASE_URL, timeout=1)
            break
        except Exception:
            time.sleep(0.2)
    else:
        proc.kill()
        raise RuntimeError("Không khởi động được server")
    yield BASE_URL
    proc.terminate()
    proc.wait()


@pytest.fixture
def driver(server):
    opts = webdriver.ChromeOptions()
    if os.environ.get("HEADLESS", "1") != "0":
        opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--window-size=1366,900")
    opts.add_argument("--lang=vi-VN")
    if os.environ.get("CHROME_BINARY"):
        opts.binary_location = os.environ["CHROME_BINARY"]
    service = Service(os.environ["CHROMEDRIVER"]) if os.environ.get("CHROMEDRIVER") else Service()
    drv = webdriver.Chrome(service=service, options=opts)
    drv.get(server)
    yield drv
    drv.quit()


class UI:
    """Các thao tác dùng chung (page-object rút gọn)."""

    def __init__(self, driver):
        self.d = driver
        self.wait = WebDriverWait(driver, 5)

    def el(self, css):
        return self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, css)))

    def visible(self, css):
        return self.wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, css)))

    def type(self, css, text):
        e = self.visible(css)
        e.clear()
        e.send_keys(text)

    def click(self, css):
        self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, css))).click()

    def text_of(self, css):
        return self.visible(css).text

    def wait_text(self, css, text):
        self.wait.until(EC.text_to_be_present_in_element((By.CSS_SELECTOR, css), text))
        return self.d.find_element(By.CSS_SELECTOR, css).text

    def login(self, username, password):
        self.type("#login-username", username)
        self.type("#login-password", password)
        self.click("#login-btn")

    def login_admin(self):
        self.login("admin", "Admin@123")
        self.visible("#page-app")

    def login_staff(self):
        self.login("nhanvien", "Nhanvien123")
        self.visible("#page-app")

    @staticmethod
    def random_phone():
        """Sinh số di động hợp lệ, không trùng giữa các test (số điện thoại là duy nhất)."""
        while True:
            tail = "".join(random.choice("0123456789") for _ in range(7))
            if len(set(tail)) > 2:
                return random.choice(["091", "098", "086", "070", "088"]) + tail

    def add_customer(self, code, name, phone=None, address="Số 1 Nguyễn Trác, Yên Nghĩa, Hà Nội"):
        phone = phone or self.random_phone()
        self.click("#nav-customers")
        self.type("#cus-code", code)
        self.type("#cus-name", name)
        self.type("#cus-phone", phone)
        self.type("#cus-address", address)
        self.click("#cus-save-btn")


@pytest.fixture
def ui(driver):
    return UI(driver)
