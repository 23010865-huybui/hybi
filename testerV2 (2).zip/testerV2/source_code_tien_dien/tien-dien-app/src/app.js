'use strict';
const path = require('path');
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { getTariff, saveTariff } = require('./db');
const { calculateBill, validateTariff, BillingError, CUSTOMER_TYPES } = require('./billing/calculator');
const { validateRegister, validateCustomer, validateReading, toInt } = require('./validators');
const Rules = require('../public/rules');
const { analyzePhone } = Rules;

const JWT_SECRET = process.env.JWT_SECRET || 'tien-dien-dev-secret';
const TOKEN_TTL = '8h';

function mapCustomer(r) {
  return {
    id: r.id,
    code: r.code,
    name: r.name,
    phone: r.phone,
    address: r.address,
    type: r.type,
    householdCount: r.household_count,
    personCount: r.person_count,
  };
}

function mapBill(r) {
  return {
    id: r.id,
    customerId: r.customer_id,
    customerCode: r.code,
    customerName: r.name,
    month: r.month,
    oldIndex: r.old_index,
    newIndex: r.new_index,
    kwh: r.kwh,
    subtotal: r.subtotal,
    vat: r.vat,
    total: r.total,
    breakdown: JSON.parse(r.breakdown),
    status: r.status,
  };
}

function customerFromBody(body) {
  return {
    code: body.code,
    name: body.name,
    phone: body.phone,
    address: body.address,
    type: body.type,
    householdCount: body.type === CUSTOMER_TYPES.HOUSEHOLD ? toInt(body.householdCount) : 1,
    personCount: body.type === CUSTOMER_TYPES.RENTER ? toInt(body.personCount) : 0,
  };
}

function parseRate(v) {
  if (typeof v === 'number') return v;
  if (typeof v === 'string' && /^\d+(\.\d+)?$/.test(v.trim())) return Number(v);
  return NaN;
}

function createApp(db) {
  const app = express();
  app.use(express.json({ limit: '100kb' }));
  app.use(express.static(path.join(__dirname, '..', 'public')));

  // ---------- Middleware ----------
  function auth(req, res, next) {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Chưa đăng nhập' });
    try {
      req.user = jwt.verify(token, JWT_SECRET);
      return next();
    } catch {
      return res.status(401).json({ error: 'Phiên đăng nhập không hợp lệ hoặc đã hết hạn' });
    }
  }
  function adminOnly(req, res, next) {
    if (req.user.role !== 'ADMIN') return res.status(403).json({ error: 'Chỉ quản trị viên được thực hiện thao tác này' });
    return next();
  }

  // ---------- Auth ----------
  app.post('/api/auth/register', (req, res) => {
    const body = req.body || {};
    const errors = validateRegister(body);
    if (errors.length) return res.status(400).json({ error: errors.join('; '), errors });
    const exists = db.prepare('SELECT id FROM users WHERE username = ? COLLATE NOCASE').get(body.username.trim());
    if (exists) return res.status(409).json({ error: 'Tên đăng nhập đã tồn tại' });
    const info = db
      .prepare('INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, ?)')
      .run(body.username.trim(), bcrypt.hashSync(body.password, 8), Rules.checkPersonName(body.fullName, 'Họ tên').value, 'STAFF');
    return res.status(201).json({ id: Number(info.lastInsertRowid), username: body.username, role: 'STAFF' });
  });

  app.post('/api/auth/login', (req, res) => {
    const { username, password } = req.body || {};
    if (!username || !password) return res.status(400).json({ error: 'Vui lòng nhập tên đăng nhập và mật khẩu' });
    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
    if (!user || !bcrypt.compareSync(password, user.password_hash)) {
      return res.status(401).json({ error: 'Tên đăng nhập hoặc mật khẩu không đúng' });
    }
    const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, JWT_SECRET, { expiresIn: TOKEN_TTL });
    return res.json({ token, user: { id: user.id, username: user.username, fullName: user.full_name, role: user.role } });
  });

  // ---------- Tính nhanh ----------
  app.post('/api/calculate', auth, (req, res) => {
    const b = req.body || {};
    try {
      const result = calculateBill({
        kwh: toInt(b.kwh),
        customerType: b.customerType,
        householdCount: toInt(b.householdCount ?? 1),
        personCount: toInt(b.personCount ?? 0),
        tariff: getTariff(db),
      });
      return res.json(result);
    } catch (e) {
      if (e instanceof BillingError) return res.status(400).json({ error: e.message, code: e.code });
      throw e;
    }
  });

  // ---------- Khách hàng ----------
  app.get('/api/customers', auth, (req, res) => {
    const raw = (req.query.q || '').trim();
    // Nếu từ khóa là số điện thoại (kể cả dạng +84, có dấu cách) thì tìm theo số đã chuẩn hóa
    const asPhone = analyzePhone(raw);
    const q = `%${asPhone.ok ? asPhone.normalized : raw}%`;
    const rows = db
      .prepare('SELECT * FROM customers WHERE code LIKE ? OR name LIKE ? OR phone LIKE ? ORDER BY code')
      .all(q, q, q);
    res.json(rows.map(mapCustomer));
  });

  app.get('/api/customers/:id', auth, (req, res) => {
    const row = db.prepare('SELECT * FROM customers WHERE id = ?').get(toInt(req.params.id));
    if (!row) return res.status(404).json({ error: 'Không tìm thấy khách hàng' });
    return res.json(mapCustomer(row));
  });

  app.post('/api/customers', auth, (req, res) => {
    const c = customerFromBody(req.body || {});
    const errors = validateCustomer(c);
    if (errors.length) return res.status(400).json({ error: errors.join('; '), errors });
    if (db.prepare('SELECT id FROM customers WHERE code = ?').get(c.code)) {
      return res.status(409).json({ error: 'Mã khách hàng đã tồn tại' });
    }
    const dupPhone = db.prepare('SELECT code FROM customers WHERE phone = ?').get(c.phone);
    if (dupPhone) {
      return res.status(409).json({ error: `Số điện thoại đã được dùng cho khách hàng ${dupPhone.code}` });
    }
    const info = db
      .prepare('INSERT INTO customers (code, name, phone, address, type, household_count, person_count) VALUES (?, ?, ?, ?, ?, ?, ?)')
      .run(c.code, c.name, c.phone, c.address, c.type, c.householdCount, c.personCount);
    const row = db.prepare('SELECT * FROM customers WHERE id = ?').get(info.lastInsertRowid);
    return res.status(201).json(mapCustomer(row));
  });

  app.put('/api/customers/:id', auth, (req, res) => {
    const id = toInt(req.params.id);
    const existing = db.prepare('SELECT * FROM customers WHERE id = ?').get(id);
    if (!existing) return res.status(404).json({ error: 'Không tìm thấy khách hàng' });
    const c = customerFromBody({ ...req.body, code: existing.code });
    const errors = validateCustomer(c);
    if (errors.length) return res.status(400).json({ error: errors.join('; '), errors });
    const dupPhone = db.prepare('SELECT code FROM customers WHERE phone = ? AND id <> ?').get(c.phone, id);
    if (dupPhone) {
      return res.status(409).json({ error: `Số điện thoại đã được dùng cho khách hàng ${dupPhone.code}` });
    }
    db.prepare('UPDATE customers SET name = ?, phone = ?, address = ?, type = ?, household_count = ?, person_count = ? WHERE id = ?')
      .run(c.name, c.phone, c.address, c.type, c.householdCount, c.personCount, id);
    return res.json(mapCustomer(db.prepare('SELECT * FROM customers WHERE id = ?').get(id)));
  });

  app.delete('/api/customers/:id', auth, (req, res) => {
    const id = toInt(req.params.id);
    if (!db.prepare('SELECT id FROM customers WHERE id = ?').get(id)) {
      return res.status(404).json({ error: 'Không tìm thấy khách hàng' });
    }
    const n = db.prepare('SELECT COUNT(*) AS n FROM bills WHERE customer_id = ?').get(id).n;
    if (n > 0) return res.status(409).json({ error: 'Không thể xóa khách hàng đã có hóa đơn' });
    db.prepare('DELETE FROM customers WHERE id = ?').run(id);
    return res.status(204).end();
  });

  app.get('/api/customers/:id/last-reading', auth, (req, res) => {
    const row = db
      .prepare('SELECT month, new_index FROM bills WHERE customer_id = ? ORDER BY month DESC LIMIT 1')
      .get(toInt(req.params.id));
    res.json(row ? { month: row.month, newIndex: row.new_index } : null);
  });

  // ---------- Ghi chỉ số & Hóa đơn ----------
  app.post('/api/bills', auth, (req, res) => {
    const b = req.body || {};
    const customer = db.prepare('SELECT * FROM customers WHERE id = ?').get(toInt(b.customerId));
    if (!customer) return res.status(404).json({ error: 'Không tìm thấy khách hàng' });

    const last = db
      .prepare('SELECT month, new_index FROM bills WHERE customer_id = ? ORDER BY month DESC LIMIT 1')
      .get(customer.id);
    // Chỉ số cũ lấy từ kỳ trước nếu đã có; nếu chưa có kỳ nào thì dùng giá trị nhập (mặc định 0)
    const reading = {
      month: typeof b.month === 'string' ? b.month.trim() : b.month,
      oldIndex: last ? last.new_index : toInt(b.oldIndex ?? 0),
      newIndex: toInt(b.newIndex),
    };
    const errors = validateReading(reading);
    if (errors.length) return res.status(400).json({ error: errors.join('; '), errors });

    if (last) {
      if (reading.month === last.month || db.prepare('SELECT id FROM bills WHERE customer_id = ? AND month = ?').get(customer.id, reading.month)) {
        return res.status(409).json({ error: `Kỳ ${reading.month} đã được ghi chỉ số` });
      }
      if (reading.month < last.month) {
        return res.status(400).json({ error: `Kỳ ghi chỉ số phải sau kỳ gần nhất (${last.month})` });
      }
    }

    const result = calculateBill({
      kwh: reading.newIndex - reading.oldIndex,
      customerType: customer.type,
      householdCount: customer.household_count,
      personCount: customer.person_count,
      tariff: getTariff(db),
    });
    const info = db
      .prepare(`INSERT INTO bills (customer_id, month, old_index, new_index, kwh, subtotal, vat, total, breakdown, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(customer.id, reading.month, reading.oldIndex, reading.newIndex, result.kwh, result.subtotal, result.vat,
        result.total, JSON.stringify(result.breakdown), req.user.id);
    const row = db
      .prepare('SELECT b.*, c.code, c.name FROM bills b JOIN customers c ON c.id = b.customer_id WHERE b.id = ?')
      .get(info.lastInsertRowid);
    return res.status(201).json(mapBill(row));
  });

  app.get('/api/bills', auth, (req, res) => {
    const where = [];
    const params = [];
    if (req.query.customerId) { where.push('b.customer_id = ?'); params.push(toInt(req.query.customerId)); }
    if (req.query.month) { where.push('b.month = ?'); params.push(String(req.query.month)); }
    if (req.query.status) { where.push('b.status = ?'); params.push(String(req.query.status)); }
    const sql = `SELECT b.*, c.code, c.name FROM bills b JOIN customers c ON c.id = b.customer_id
                 ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY b.month DESC, c.code`;
    res.json(db.prepare(sql).all(...params).map(mapBill));
  });

  app.patch('/api/bills/:id/pay', auth, (req, res) => {
    const id = toInt(req.params.id);
    const bill = db.prepare('SELECT * FROM bills WHERE id = ?').get(id);
    if (!bill) return res.status(404).json({ error: 'Không tìm thấy hóa đơn' });
    if (bill.status === 'DA_THANH_TOAN') return res.status(409).json({ error: 'Hóa đơn đã được thanh toán' });
    db.prepare("UPDATE bills SET status = 'DA_THANH_TOAN' WHERE id = ?").run(id);
    return res.json({ id, status: 'DA_THANH_TOAN' });
  });

  // ---------- Biểu giá ----------
  app.get('/api/tariff', auth, (req, res) => res.json(getTariff(db)));

  app.put('/api/tariff', auth, adminOnly, (req, res) => {
    const b = req.body || {};
    const current = getTariff(db);
    const tariff = {
      name: typeof b.name === 'string' && b.name.trim() ? b.name.trim() : current.name,
      tiers: Array.isArray(b.tiers)
        ? b.tiers.map((t, i, arr) => ({
          width: i === arr.length - 1 ? null : toInt(t.width),
          price: toInt(t.price),
        }))
        : b.tiers,
      undeclaredPrice: toInt(b.undeclaredPrice),
      vatRate: parseRate(b.vatRate),
    };
    try {
      validateTariff(tariff);
    } catch (e) {
      if (e instanceof BillingError) return res.status(400).json({ error: e.message });
      throw e;
    }
    saveTariff(db, tariff);
    return res.json(tariff);
  });

  // ---------- Lỗi chung ----------
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Dữ liệu gửi lên không đúng định dạng JSON' });
    console.error(err);
    return res.status(500).json({ error: 'Lỗi hệ thống' });
  });

  return app;
}

module.exports = { createApp };
