'use strict';
const { DatabaseSync } = require('node:sqlite');
const bcrypt = require('bcryptjs');
const { DEFAULT_TARIFF } = require('./billing/tariff');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('ADMIN','STAFF')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  address TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('HO_GIA_DINH','THUE_NHA')),
  household_count INTEGER NOT NULL DEFAULT 1,
  person_count INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS bills (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  month TEXT NOT NULL,
  old_index INTEGER NOT NULL,
  new_index INTEGER NOT NULL,
  kwh INTEGER NOT NULL,
  subtotal INTEGER NOT NULL,
  vat INTEGER NOT NULL,
  total INTEGER NOT NULL,
  breakdown TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'CHUA_THANH_TOAN' CHECK (status IN ('CHUA_THANH_TOAN','DA_THANH_TOAN')),
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (customer_id, month)
);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
`;

function openDb(file = ':memory:') {
  const db = new DatabaseSync(file);
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec(SCHEMA);
  seed(db);
  return db;
}

function seed(db) {
  const count = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  if (count === 0) {
    const insert = db.prepare('INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, ?)');
    insert.run('admin', bcrypt.hashSync('Admin@123', 8), 'Quản trị viên', 'ADMIN');
    insert.run('nhanvien', bcrypt.hashSync('Nhanvien123', 8), 'Nhân viên ghi điện', 'STAFF');
  }
  const t = db.prepare("SELECT value FROM settings WHERE key = 'tariff'").get();
  if (!t) {
    db.prepare("INSERT INTO settings (key, value) VALUES ('tariff', ?)").run(JSON.stringify(DEFAULT_TARIFF));
  }
}

function getTariff(db) {
  return JSON.parse(db.prepare("SELECT value FROM settings WHERE key = 'tariff'").get().value);
}

function saveTariff(db, tariff) {
  db.prepare("UPDATE settings SET value = ? WHERE key = 'tariff'").run(JSON.stringify(tariff));
}

module.exports = { openDb, getTariff, saveTariff };
