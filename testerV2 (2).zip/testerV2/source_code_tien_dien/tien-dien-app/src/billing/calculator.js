'use strict';

const CUSTOMER_TYPES = Object.freeze({
  HOUSEHOLD: 'HO_GIA_DINH', // hộ gia đình: định mức nhân theo số hộ dùng chung công tơ
  RENTER: 'THUE_NHA', // sinh viên / người lao động thuê nhà: 4 người = 1 hộ
});

const MAX_KWH = 1000000;
const MAX_HOUSEHOLDS = 20;
const MAX_PERSONS = 100;

class BillingError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'BillingError';
    this.code = code;
  }
}

/**
 * Hệ số định mức: số "hộ quy đổi" dùng để nhân độ rộng mỗi bậc.
 * Trả về null nếu người thuê nhà không kê khai số người (áp dụng giá đồng nhất).
 */
function getNormMultiplier(customerType, householdCount, personCount) {
  if (customerType === CUSTOMER_TYPES.HOUSEHOLD) {
    if (!Number.isInteger(householdCount) || householdCount < 1 || householdCount > MAX_HOUSEHOLDS) {
      throw new BillingError('INVALID_HOUSEHOLD_COUNT', `Số hộ dùng chung công tơ phải là số nguyên từ 1 đến ${MAX_HOUSEHOLDS}`);
    }
    return householdCount;
  }
  if (customerType === CUSTOMER_TYPES.RENTER) {
    if (!Number.isInteger(personCount) || personCount < 0 || personCount > MAX_PERSONS) {
      throw new BillingError('INVALID_PERSON_COUNT', `Số người thuê phải là số nguyên từ 0 đến ${MAX_PERSONS}`);
    }
    if (personCount === 0) return null;
    return personCount / 4;
  }
  throw new BillingError('INVALID_CUSTOMER_TYPE', 'Loại khách hàng không hợp lệ');
}

function validateTariff(tariff) {
  if (!tariff || !Array.isArray(tariff.tiers) || tariff.tiers.length === 0) {
    throw new BillingError('INVALID_TARIFF', 'Biểu giá không hợp lệ');
  }
  tariff.tiers.forEach((t, i) => {
    const isLast = i === tariff.tiers.length - 1;
    if (!Number.isInteger(t.price) || t.price <= 0) {
      throw new BillingError('INVALID_TARIFF', `Đơn giá bậc ${i + 1} phải là số nguyên dương`);
    }
    if (isLast) {
      if (t.width !== null) throw new BillingError('INVALID_TARIFF', 'Bậc cuối cùng không được giới hạn sản lượng');
    } else if (!Number.isInteger(t.width) || t.width <= 0) {
      throw new BillingError('INVALID_TARIFF', `Sản lượng bậc ${i + 1} phải là số nguyên dương`);
    }
  });
  if (!Number.isFinite(tariff.vatRate) || tariff.vatRate < 0 || tariff.vatRate > 0.2) {
    throw new BillingError('INVALID_TARIFF', 'Thuế suất VAT phải trong khoảng 0 - 20%');
  }
  if (!Number.isInteger(tariff.undeclaredPrice) || tariff.undeclaredPrice <= 0) {
    throw new BillingError('INVALID_TARIFF', 'Đơn giá khi không kê khai phải là số nguyên dương');
  }
}

/**
 * Tính tiền điện sinh hoạt theo biểu giá bậc thang.
 * @param {object} p
 * @param {number} p.kwh            sản lượng điện tiêu thụ (kWh, số nguyên >= 0)
 * @param {string} p.customerType   HO_GIA_DINH | THUE_NHA
 * @param {number} p.householdCount số hộ dùng chung công tơ (HO_GIA_DINH)
 * @param {number} p.personCount    số người thuê đã kê khai (THUE_NHA), 0 = không kê khai
 * @param {object} p.tariff         biểu giá
 */
function calculateBill({ kwh, customerType = CUSTOMER_TYPES.HOUSEHOLD, householdCount = 1, personCount = 0, tariff }) {
  if (!Number.isInteger(kwh) || kwh < 0 || kwh > MAX_KWH) {
    throw new BillingError('INVALID_KWH', `Sản lượng điện phải là số nguyên từ 0 đến ${MAX_KWH} kWh`);
  }
  validateTariff(tariff);
  const multiplier = getNormMultiplier(customerType, householdCount, personCount);

  const breakdown = [];
  if (multiplier === null) {
    // Không kê khai số người: một đơn giá cho toàn bộ sản lượng
    if (kwh > 0) {
      breakdown.push({ tier: 0, kwh, price: tariff.undeclaredPrice, amount: kwh * tariff.undeclaredPrice });
    }
  } else {
    let remaining = kwh;
    for (let i = 0; i < tariff.tiers.length && remaining > 0; i++) {
      const { width, price } = tariff.tiers[i];
      const cap = width === null ? Infinity : Math.round(width * multiplier);
      const used = Math.min(remaining, cap);
      if (used > 0) {
        breakdown.push({ tier: i + 1, kwh: used, price, amount: used * price });
        remaining -= used;
      }
    }
  }

  const subtotal = breakdown.reduce((sum, b) => sum + b.amount, 0);
  const vat = Math.round(subtotal * tariff.vatRate);
  return { kwh, multiplier, breakdown, subtotal, vat, total: subtotal + vat };
}

module.exports = {
  calculateBill,
  getNormMultiplier,
  validateTariff,
  BillingError,
  CUSTOMER_TYPES,
  MAX_KWH,
  MAX_HOUSEHOLDS,
  MAX_PERSONS,
};
