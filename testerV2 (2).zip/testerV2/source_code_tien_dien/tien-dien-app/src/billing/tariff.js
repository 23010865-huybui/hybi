'use strict';
/**
 * Biểu giá bán lẻ điện sinh hoạt mặc định (chưa gồm VAT).
 * Nguồn: Quyết định 1279/QĐ-BCT ngày 09/05/2025 của Bộ Công Thương (6 bậc).
 * width = số kWh của bậc cho 01 hộ; null = không giới hạn (bậc cuối).
 * Biểu giá có thể được quản trị viên chỉnh sửa trong hệ thống.
 */
const DEFAULT_TARIFF = Object.freeze({
  name: 'Biểu giá điện sinh hoạt 6 bậc (QĐ 1279/QĐ-BCT)',
  tiers: [
    { width: 50, price: 1984 },
    { width: 50, price: 2050 },
    { width: 100, price: 2380 },
    { width: 100, price: 2998 },
    { width: 100, price: 3350 },
    { width: null, price: 3460 },
  ],
  // Đơn giá áp dụng cho toàn bộ sản lượng khi người thuê nhà không kê khai số người
  undeclaredPrice: 2380,
  vatRate: 0.08,
});

module.exports = { DEFAULT_TARIFF };
