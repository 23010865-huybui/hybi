'use strict';
const { CUSTOMER_TYPES, MAX_HOUSEHOLDS, MAX_PERSONS } = require('./billing/calculator');
const Rules = require('../public/rules');

const { analyzePhone } = Rules;
const MAX_METER_INDEX = 99999999;

function isBlank(v) {
  return v === undefined || v === null || String(v).trim() === '';
}

/** Mỗi hàm validate trả về mảng thông báo lỗi; mảng rỗng = hợp lệ. */
function validateRegister({ username, password, confirmPassword, fullName }) {
  const errors = [];
  errors.push(...Rules.checkUsername(username).errors);
  errors.push(...Rules.checkPersonName(fullName, 'Họ tên').errors);
  errors.push(...Rules.checkPassword(password, username).errors);
  if (!isBlank(password) && password !== confirmPassword) errors.push('Mật khẩu xác nhận không khớp');
  return errors;
}

/**
 * Kiểm tra khách hàng. Nếu hợp lệ, các trường code, name, phone, address của c được thay bằng
 * giá trị đã chuẩn hóa (viết hoa chữ đầu, bỏ khoảng trắng thừa, số điện thoại dạng 0xxxxxxxxx, tên tỉnh chuẩn).
 */
function validateCustomer(c) {
  const errors = [];
  const code = Rules.checkCustomerCode(c.code);
  const name = Rules.checkPersonName(c.name, 'Tên khách hàng');
  const phone = analyzePhone(c.phone);
  const addr = Rules.checkAddress(c.address);
  errors.push(...code.errors, ...name.errors);
  if (!phone.ok) errors.push(phone.message);
  errors.push(...addr.errors);
  if (c.type === CUSTOMER_TYPES.HOUSEHOLD) {
    if (!Number.isInteger(c.householdCount) || c.householdCount < 1 || c.householdCount > MAX_HOUSEHOLDS) {
      errors.push(`Số hộ dùng chung công tơ từ 1 đến ${MAX_HOUSEHOLDS}`);
    }
  } else if (c.type === CUSTOMER_TYPES.RENTER) {
    if (!Number.isInteger(c.personCount) || c.personCount < 0 || c.personCount > MAX_PERSONS) {
      errors.push(`Số người thuê từ 0 đến ${MAX_PERSONS}`);
    }
  } else {
    errors.push('Loại khách hàng không hợp lệ');
  }
  if (!errors.length) {
    c.code = code.value;
    c.name = name.value;
    c.phone = phone.normalized;
    c.address = addr.value;
  }
  return errors;
}

function currentMonth(now = new Date()) {
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
}

function validateReading({ month, oldIndex, newIndex }, now = new Date()) {
  const errors = [];
  if (isBlank(month)) errors.push('Kỳ ghi chỉ số không được để trống');
  else if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) errors.push('Kỳ ghi chỉ số có dạng YYYY-MM');
  else if (month < '2000-01') errors.push('Kỳ ghi chỉ số phải từ 2000-01 trở đi');
  else if (month > currentMonth(now)) errors.push(`Kỳ ghi chỉ số không được sau tháng hiện tại (${currentMonth(now)})`);
  if (!Number.isInteger(oldIndex) || oldIndex < 0 || oldIndex > MAX_METER_INDEX) {
    errors.push(`Chỉ số cũ phải là số nguyên từ 0 đến ${MAX_METER_INDEX}`);
  }
  if (!Number.isInteger(newIndex) || newIndex < 0 || newIndex > MAX_METER_INDEX) {
    errors.push(`Chỉ số mới phải là số nguyên từ 0 đến ${MAX_METER_INDEX}`);
  } else if (Number.isInteger(oldIndex) && newIndex < oldIndex) {
    errors.push('Chỉ số mới không được nhỏ hơn chỉ số cũ');
  }
  return errors;
}

/** Chuyển giá trị nhập (chuỗi hoặc số) sang số nguyên; NaN nếu không phải số nguyên. */
function toInt(v) {
  if (typeof v === 'number') return Number.isInteger(v) ? v : NaN;
  if (typeof v !== 'string' || !/^-?\d+$/.test(v.trim())) return NaN;
  return parseInt(v.trim(), 10);
}

module.exports = { validateRegister, validateCustomer, validateReading, toInt, MAX_METER_INDEX };
