# Hệ thống tính tiền điện sinh hoạt

Bài tập lớn học phần **Đánh giá và kiểm định chất lượng phần mềm** – Trường Đại học Phenikaa.

Ứng dụng web tính tiền điện sinh hoạt theo biểu giá bậc thang 6 bậc (QĐ 1279/QĐ-BCT), gồm quản lý khách hàng, ghi chỉ số công tơ, lập hóa đơn và cấu hình biểu giá.

## Yêu cầu
- Node.js **22.13 trở lên** (dùng module `node:sqlite` có sẵn, không cần cài CSDL)
- Python 3.10+ và Google Chrome (chỉ để chạy test Selenium)

## Chạy ứng dụng
```bash
npm install
npm start          # mở http://localhost:3000
```
Tài khoản mẫu: `admin / Admin@123` (Quản trị viên), `nhanvien / Nhanvien123` (Nhân viên).
Dữ liệu lưu ở `data.sqlite`; xóa file này để làm lại từ đầu.

## Chạy kiểm thử
| Lệnh | Nội dung |
|---|---|
| `npm test` | 243 test đơn vị + API (Jest, Supertest) |
| `npm run coverage` | Đo độ phủ, báo cáo HTML ở `coverage/index.html` |
| `npm run lint` | Phân tích tĩnh ESLint |
| `cd selenium && pip install -r requirements.txt && pytest -v` | 25 kịch bản Selenium (tự khởi động server cổng 3100) |
| `node tests/perf/perf.js http://localhost:3000 1000 20` | Kiểm thử hiệu năng API (cần `npm start` trước) |
| `cd selenium && python perf_ui.py` | Đo thời gian tải trang / thao tác giao diện |

Chạy Selenium ở chế độ có giao diện: `HEADLESS=0 pytest -v`.

## Cấu trúc
```
server.js                  # khởi động server
src/app.js                 # REST API (Express)
src/billing/calculator.js  # tính tiền bậc thang  <- đối tượng kiểm thử hộp trắng
src/billing/tariff.js      # biểu giá mặc định
src/validators.js          # kiểm tra dữ liệu phía server
public/rules.js            # bộ ràng buộc dùng chung trình duyệt + server (SĐT, họ tên, địa chỉ, tài khoản)
src/db.js                  # SQLite, dữ liệu mẫu
public/                    # giao diện HTML/CSS/JS
tests/unit, tests/api      # Jest
tests/perf/perf.js         # hiệu năng API
selenium/                  # Selenium + pytest
reports/                   # kết quả chạy test lần cuối
```
